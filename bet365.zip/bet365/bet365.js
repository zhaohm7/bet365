const puppeteer = require("puppeteer-extra");
const path = require("path");

const StealthPlugin = require("puppeteer-extra-plugin-stealth")();
StealthPlugin.enabledEvasions.delete("chrome.runtime");
StealthPlugin.enabledEvasions.delete("iframe.contentWindow");

const request = require('request');
puppeteer.use(StealthPlugin);
let bUrl = "https://bet365.com.au";

(async () => {

const puppeteerBrowser = await puppeteer.launch({
  headless: false,
  userDataDir: path.resolve(__dirname, "./perfil"),
  args: [
    "--disable-infobars",
    "--no-sandbox",
    "--disable-blink-features=AutomationControlled",
  ],
  ignoreDefaultArgs: ["--enable-automation"],
});

// this.pupeteerBrowser = await puppeteer.connect({browserURL: 'http://localhost:9992'})

/**@type  import('puppeteer').Page **/
const puppeteerPage = await puppeteerBrowser.newPage();

await puppeteerPage.evaluateOnNewDocument(() => {
  window.qs = document.querySelector;
  window.qsAll = document.querySelectorAll;
  
  let n = 1;

  Object.defineProperty(navigator, "maxTouchPoints", {
    get() {
      setTimeout(() => (n = 0), 0);
      return n;
    },
  });

  navigator.permissions.query = i => ({then: f => f({state: "prompt", onchange: null})});
});

await puppeteerPage.goto(bUrl, { waitUntil: "networkidle0" });
//await this.pupeteerPage.setViewport({ width: 1200, height: 720 });

await puppeteerPage.evaluate(() => {
  document.querySelector = window.qs;
  document.querySelectorAll = window.qsAll;
});

await puppeteerPage.evaluate(() => {
  location.hash = '/AS/B2/';
});

await puppeteerPage.waitForTimeout(3000);

await puppeteerPage.evaluate(() => {
  location.hash = '/AC/B1/C1/D13/E108/F16/';
});

setInterval(async() => {
  try {
  console.log("refresh")
  await puppeteerPage.reload()
  } catch(err) {
    await puppeteerPage.goto(bUrl, { waitUntil: "networkidle0" });
  }
}, 20 * 1000)

var token = null

puppeteerPage.on('request', async (requests) => {
    let t = await requests.headers();
    try {

        let _token = t["x-net-sync-term"];        

        if (_token)
        {  
          console.log(_token);

          const current_url_cookies = await puppeteerPage.cookies();
          let cookie_string = []
          current_url_cookies.forEach(item => {
            cookie_string.unshift(item['name'] + "=" + item["value"])          
          })
              
          let _cookie = cookie_string.join('; ')

          console.log(_cookie)

          if (typeof _token !== "undefined" && _token !== null &&  token != _token)
          {
              token = _token
              console.log(token, _cookie)
              request.post('http://localhost:8000/api/bet365/cookie/1', {form:{token:_token, cookie: _cookie}}, function(err, response, body) {
                if (err)
                  console.log("error", err)
              })
          }
        }
    } catch(err) {
        console.log(err)
    }    
});

})();
