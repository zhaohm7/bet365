activate_this = 'G:/Upwork/20190816_react/OddAlert_v3/web_backend/venv/Scripts/activate_this.py'
# execfile(activate_this, dict(__file__=activate_this))
exec(open(activate_this).read(),dict(__file__=activate_this))

import os
import sys
import site

# Add the site-packages of the chosen virtualenv to work with
site.addsitedir('G:/Upwork/20190816_react/OddAlert_v3/web_backend/venv/Lib/site-packages')

# Add the app's directory to the PYTHONPATH
sys.path.append('G:/Upwork/20190816_react/OddAlert_v3/web_backend')
sys.path.append('G:/Upwork/20190816_react/OddAlert_v3/web_backend/odd_alert_back')

os.environ['DJANGO_SETTINGS_MODULE'] = 'odd_alert_back.settings'
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "odd_alert_back.settings")

from django.core.wsgi import get_wsgi_application
application = get_wsgi_application()