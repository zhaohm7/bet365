from rest_framework import serializers
from django.contrib import auth
from django.db import models
from django.db. models import Q
from .models import SportsInfo
from .models import Bet365Event, Bet365MarketInfo, BetFredEvent, BetFredMarketInfo
from datetime import datetime, timedelta, timezone
from .utils import get_current_time_string

class SportsInfoSerializer(serializers.ModelSerializer):    
    class Meta:
        model = SportsInfo
        fields = '__all__'         

class Bet365MarketInfoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Bet365MarketInfo
        fields = '__all__'

#Bet365 
class Bet365EventSerializer(serializers.ModelSerializer):    
    #re = Bet365MarketInfo.objects.filter(updateTime__gte=now)
    horse = Bet365MarketInfoSerializer(read_only=True, many=True)
    
    class Meta:
        model = Bet365Event
        fields = '__all__'

#betfred
class BetFredMarketInfoSerializer(serializers.ModelSerializer):    
    class Meta:
        model = BetFredMarketInfo
        fields = '__all__'        

class BetFredEventSerializer(serializers.ModelSerializer):
    horse = BetFredMarketInfoSerializer(read_only=True, many=True)
    class Meta:
        model = BetFredEvent
        fields = '__all__'
