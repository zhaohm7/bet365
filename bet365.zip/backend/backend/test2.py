from dateutil import parser
import pytz
from datetime import datetime, timedelta

result = "F|CL;TK=BGQ=;ID=18;IT=#AC#B18#C20733749#D47#E181285#F47#;OR=0;EX=7,#AC#B18#C20733749#D47#E181285#F47#@9,BETTINGNEWS18@15,<;ED=1,#AS#B18#Q1#,0@2,#AS#B18#,1;H1=1,#AS#B18#Q1#,0@2,#AS#B18#,1;H2=;NA=,;NG=Sports/Basketball Coupon;NS=0;PV=2.0.1420.0/CC;|EV;ID=E1;IT=CC-EV_#AC#B18#C20733749#D47#E181285#F47#;NA= ;TB=Basketball,#AS#B18#¬Germany Bundesliga,#ABM#B18#C20733749#D47#E181285#F47#;EN=1;FI=101299949;CC=BB;CK=20733749;DI=1001;NM=1;SO=1;OI=101299949;|MG;SY=cm;TB=1;|MA;NA=Lines;PD=#AC#B18#C20733749#D48#E1453#F10#;IT=ACB18C20733749D47E181285F47CC-MG-AGACB18C20733749D48E1453F10;|MA;NA=Props;PD=#AC#B18#C20733749#D47#E181285#F47#;IT=ACB18C20733749D47E181285F47CC-MG-AGACB18C20733749D47E181285F47;LS=1;|MA;NA=Futures;PD=#AC#B18#C20723202#D1#E55024570#F2#;IT=ACB18C20733749D47E181285F47CC-MG-AGACB18C20723202D1E55024570F2;|MG;ID=181285;NA=Alternative Point Spread;SY=fa;PC=#AM#B18#C20733749#D47#E181285#F47#I0#;EN=2;DO=1;OI=101299949;CL=18;|MG;ID=G181285;FI=101995933;SY=fe;NA=BBC Bayreuth vs Hamburg Towers;BC=20210429190000;N2=Start Time;VI=7;LP=6;CB=??#AN#DE#SU;DO=1;CL=18;|MA;ID=M181285;NA=BBC Bayreuth;FI=101995933;SY=_a;PY=_c;|PA;ID=1672836839;NA=-4.5;OD=06*75;|PA;ID=1672836840;NA=-4.0;OD=46*0;|PA;ID=1672836842;NA=-3.5;OD=47*0;|PA;ID=1672836843;NA=-3.0;OD=76*45;|PA;ID=1672836844;NA=-2.5;OD=14*75;|PA;ID=1672836846;NA=-2.0;OD=62*75;|PA;ID=1672836847;NA=-1.5;OD=42*45;|PA;ID=1672836848;NA=-1.0;OD==*0;|PA;ID=1672836852;NA=+1.0;OD=2*0;|PA;ID=1672836853;NA=+1.5;OD=0*1;|PA;ID=1672836855;NA=+2.0;OD=3*0;|PA;ID=1672836856;NA=+2.5;OD=44*45;|PA;ID=1672836857;NA=+3.0;OD=74*75;|PA;ID=1672836858;NA=+3.5;OD=4*4;|PA;ID=1672836859;NA=+4.0;OD=0*3;|PA;ID=1672836860;NA=+4.5;OD=1*0;|PA;ID=1672836861;NA=+5.0;OD=0*2;|PA;ID=1672836862;NA=+5.5;OD=1*3;|PA;ID=1672836863;NA=+6.0;OD=0*=;|PA;ID=1672836865;NA=+6.5;OD=1*2;|PA;ID=1672836866;NA=+7.0;OD=0*<;|PA;ID=1672836867;NA=+7.5;OD=4*7;|PA;ID=1672836869;NA=+8.0;OD=45*74;|PA;ID=1672836871;NA=+8.5;OD=45*76;|PA;ID=1672836872;NA=+9.0;OD=7*0;|PA;ID=1672836874;NA=+9.5;OD=0*46;|PA;ID=1672836875;NA=+10.0;OD=45*7<;|PA;ID=1672836876;NA=+10.5;OD=4*6;|PA;ID=1672836878;NA=+11.0;OD=75*3<;|PA;ID=1672836879;NA=+11.5;OD=7*2;|MA;ID=M181285;NA=Hamburg Towers;FI=101995933;SY=_a;PY=_c;|PA;ID=1672836880;NA=+4.5;OD=1*40;|PA;ID=1672836881;NA=+4.0;OD=45*62;|PA;ID=1672836882;NA=+3.5;OD=45*66;|PA;ID=1672836883;NA=+3.0;OD=0*43;|PA;ID=1672836884;NA=+2.5;OD=0*41;|PA;ID=1672836885;NA=+2.0;OD=0*46;|PA;ID=1672836887;NA=+1.5;OD=0*47;|PA;ID=1672836888;NA=+1.0;OD=0*44;|PA;ID=1672836892;NA=-1.0;OD=45*4<;|PA;ID=1672836893;NA=-1.5;OD=1*2;|PA;ID=1672836894;NA=-2.0;OD=0*=;|PA;ID=1672836895;NA=-2.5;OD=1*3;|PA;ID=1672836897;NA=-3.0;OD=0*2;|PA;ID=1672836898;NA=-3.5;OD=75*76;|PA;ID=1672836899;NA=-4.0;OD=0*3;|PA;ID=1672836900;NA=-4.5;OD=75*76;|PA;ID=1672836901;NA=-5.0;OD=4*4;|PA;ID=1672836902;NA=-5.5;OD=44*45;|PA;ID=1672836903;NA=-6.0;OD=3*0;|PA;ID=1672836904;NA=-6.5;OD=0*1;|PA;ID=1672836906;NA=-7.0;OD=46*45;|PA;ID=1672836907;NA=-7.5;OD=3*1;|PA;ID=1672836908;NA=-8.0;OD=64*75;|PA;ID=1672836909;NA=-8.5;OD=66*75;|PA;ID=1672836910;NA=-9.0;OD=2*1;|PA;ID=1672836911;NA=-9.5;OD=62*75;|PA;ID=1672836912;NA=-10.0;OD=16*75;|PA;ID=1672836913;NA=-10.5;OD=<*1;|PA;ID=1672836915;NA=-11.0;OD=0*7;|PA;ID=1672836916;NA=-11.5;OD=04*75;|MG;ID=G181285;FI=101995962;SY=fe;NA=Braunschweig vs S. Oliver Wurzburg;BC=20210429190000;N2=Start Time;VI=7;LP=6;CB=??#AN#DE#SU;DO=1;CL=18;|MA;ID=M181285;NA=Braunschweig;FI=101995962;SY=_a;PY=_c;|PA;ID=1672839915;NA=-11.5;OD=44*1;|PA;ID=1672839923;NA=-11.0;OD=06*75;|PA;ID=1672839927;NA=-10.5;OD=47*0;|PA;ID=1672839928;NA=-10.0;OD=76*45;|PA;ID=1672839930;NA=-9.5;OD=16*75;|PA;ID=1672839931;NA=-9.0;OD=7*4;|PA;ID=1672839933;NA=-8.5;OD=2*1;|PA;ID=1672839935;NA=-8.0;OD=66*75;|PA;ID=1672839936;NA=-7.5;OD=64*75;|PA;ID=1672839938;NA=-7.0;OD=3*1;|PA;ID=1672839939;NA=-6.5;OD=46*45;|PA;ID=1672839941;NA=-6.0;OD=0*1;|PA;ID=1672839942;NA=-5.5;OD=3*0;|PA;ID=1672839944;NA=-5.0;OD=44*45;|PA;ID=1672839945;NA=-4.5;OD=4*4;|PA;ID=1672839947;NA=-4.0;OD=75*74;|PA;ID=1672839949;NA=-3.5;OD=45*44;|PA;ID=1672839950;NA=-3.0;OD=1*0;|PA;ID=1672839952;NA=-2.5;OD=0*2;|PA;ID=1672839954;NA=-2.0;OD=1*3;|PA;ID=1672839955;NA=-1.5;OD=0*=;|PA;ID=1672839957;NA=-1.0;OD=1*2;|PA;ID=1672839963;NA=+1.0;OD=4*7;|PA;ID=1672839965;NA=+1.5;OD=0*44;|PA;ID=1672839966;NA=+2.0;OD=0*47;|PA;ID=1672839968;NA=+2.5;OD=7*0;|PA;ID=1672839969;NA=+3.0;OD=0*41;|PA;ID=1672839971;NA=+3.5;OD=4*6;|PA;ID=1672839972;NA=+4.0;OD=45*66;|PA;ID=1672839974;NA=+4.5;OD=7*2;|MA;ID=M181285;NA=S. Oliver Wurzburg;FI=101995962;SY=_a;PY=_c;|PA;ID=1672839975;NA=+11.5;OD=4*1;|PA;ID=1672839977;NA=+11.0;OD=1*40;|PA;ID=1672839978;NA=+10.5;OD=45*66;|PA;ID=1672839981;NA=+10.0;OD=0*43;|PA;ID=1672839982;NA=+9.5;OD=45*7<;|PA;ID=1672839984;NA=+9.0;OD=1*44;|PA;ID=1672839987;NA=+8.5;OD=7*0;|PA;ID=1672839990;NA=+8.0;OD=45*76;|PA;ID=1672839994;NA=+7.5;OD=45*74;|PA;ID=1672839997;NA=+7.0;OD=4*7;|PA;ID=1672839998;NA=+6.5;OD=0*<;|PA;ID=1672839999;NA=+6.0;OD=1*2;|PA;ID=1672840000;NA=+5.5;OD=0*=;|PA;ID=1672840001;NA=+5.0;OD=1*3;|PA;ID=1672840002;NA=+4.5;OD=0*2;|PA;ID=1672840003;NA=+4.0;OD=1*0;|PA;ID=1672840004;NA=+3.5;OD=45*44;|PA;ID=1672840005;NA=+3.0;OD=75*74;|PA;ID=1672840006;NA=+2.5;OD=4*4;|PA;ID=1672840008;NA=+2.0;OD=44*45;|PA;ID=1672840010;NA=+1.5;OD=3*0;|PA;ID=1672840011;NA=+1.0;OD=0*1;|PA;ID=1672840018;NA=-1.0;OD=3*1;|PA;ID=1672840019;NA=-1.5;OD==*0;|PA;ID=1672840021;NA=-2.0;OD=42*45;|PA;ID=1672840023;NA=-2.5;OD=2*1;|PA;ID=1672840024;NA=-3.0;OD=14*75;|PA;ID=1672840026;NA=-3.5;OD=<*1;|PA;ID=1672840028;NA=-4.0;OD=47*0;|PA;ID=1672840029;NA=-4.5;OD=0*7;|MG;ID=G181285;FI=101995988;SY=fe;NA=Ratiopharm Ulm vs Crailsheim Merlins;BC=20210429203000;N2=Start Time;VI=7;LP=6;CB=??#AN#DE#SU;DO=1;CL=18;|MA;ID=M181285;NA=Ratiopharm Ulm;FI=101995988;SY=_a;PY=_c;|PA;ID=1672842613;NA=-14.5;OD=06*75;|PA;ID=1672842614;NA=-14.0;OD=46*0;|PA;ID=1672842615;NA=-13.5;OD=47*0;|PA;ID=1672842616;NA=-13.0;OD=76*45;|PA;ID=1672842617;NA=-12.5;OD=14*75;|PA;ID=1672842618;NA=-12.0;OD=6<*75;|PA;ID=1672842619;NA=-11.5;OD=42*45;|PA;ID=1672842621;NA=-11.0;OD=66*75;|PA;ID=1672842624;NA=-10.5;OD=64*75;|PA;ID=1672842626;NA=-10.0;OD=3*1;|PA;ID=1672842629;NA=-9.5;OD=46*45;|PA;ID=1672842631;NA=-9.0;OD=0*1;|PA;ID=1672842633;NA=-8.5;OD=3*0;|PA;ID=1672842635;NA=-8.0;OD=44*45;|PA;ID=1672842637;NA=-7.5;OD=4*4;|PA;ID=1672842639;NA=-7.0;OD=75*74;|PA;ID=1672842640;NA=-6.5;OD=45*44;|PA;ID=1672842642;NA=-6.0;OD=1*0;|PA;ID=1672842643;NA=-5.5;OD=0*2;|PA;ID=1672842645;NA=-5.0;OD=1*3;|PA;ID=1672842647;NA=-4.5;OD=0*=;|PA;ID=1672842648;NA=-4.0;OD=1*2;|PA;ID=1672842650;NA=-3.5;OD=0*<;|PA;ID=1672842651;NA=-3.0;OD=4*7;|PA;ID=1672842653;NA=-2.5;OD=0*44;|PA;ID=1672842656;NA=-2.0;OD=0*47;|PA;ID=1672842657;NA=-1.5;OD=7*0;|PA;ID=1672842659;NA=-1.0;OD=45*7<;|PA;ID=1672842665;NA=+1.0;OD=45*66;|PA;ID=1672842667;NA=+1.5;OD=7*2;|MA;ID=M181285;NA=Crailsheim Merlins;FI=101995988;SY=_a;PY=_c;|PA;ID=1672842668;NA=+14.5;OD=1*40;|PA;ID=1672842670;NA=+14.0;OD=45*62;|PA;ID=1672842672;NA=+13.5;OD=45*66;|PA;ID=1672842674;NA=+13.0;OD=0*43;|PA;ID=1672842675;NA=+12.5;OD=0*41;|PA;ID=1672842677;NA=+12.0;OD=45*72;|PA;ID=1672842679;NA=+11.5;OD=0*47;|PA;ID=1672842681;NA=+11.0;OD=45*76;|PA;ID=1672842682;NA=+10.5;OD=45*74;|PA;ID=1672842684;NA=+10.0;OD=4*7;|PA;ID=1672842686;NA=+9.5;OD=0*<;|PA;ID=1672842687;NA=+9.0;OD=1*2;|PA;ID=1672842690;NA=+8.5;OD=0*=;|PA;ID=1672842693;NA=+8.0;OD=1*3;|PA;ID=1672842694;NA=+7.5;OD=0*2;|PA;ID=1672842696;NA=+7.0;OD=1*0;|PA;ID=1672842698;NA=+6.5;OD=45*44;|PA;ID=1672842699;NA=+6.0;OD=75*74;|PA;ID=1672842701;NA=+5.5;OD=4*4;|PA;ID=1672842703;NA=+5.0;OD=44*45;|PA;ID=1672842704;NA=+4.5;OD=3*0;|PA;ID=1672842705;NA=+4.0;OD=0*1;|PA;ID=1672842706;NA=+3.5;OD=46*45;|PA;ID=1672842707;NA=+3.0;OD=3*1;|PA;ID=1672842708;NA=+2.5;OD==*0;|PA;ID=1672842710;NA=+2.0;OD=42*45;|PA;ID=1672842712;NA=+1.5;OD=2*1;|PA;ID=1672842714;NA=+1.0;OD=16*75;|PA;ID=1672842721;NA=-1.0;OD=47*0;|PA;ID=1672842723;NA=-1.5;OD=0*7;|MG;ID=LMAB;DO=1;SY=fc;CK=20733749;ED=Germany Bundesliga;PD=#PU#B18#C20733749#D47#E181285#F47#X4062#;IT=ACB18C20733749D47E181285F47CC-MG-AEPUB18C20733749D47E181285F47X4062;|"

result1 = "F|CL;TK=BGk=;ID=18;IT=#AC#B18#C20733749#D48#E1453#F10#;OR=0;EX=7,#AC#B18#C20733749#D48#E1453#F10#@9,BETTINGNEWS18@15,<;ED=1,#AS#B18#Q1#,0@2,#AS#B18#,1;H1=1,#AS#B18#Q1#,0@2,#AS#B18#,1;H2=;NA=,;NG=Sports/Basketball Coupon;NS=0;PV=2.0.1420.0/CC;|EV;ID=E1;IT=CC-EV_#AC#B18#C20733749#D48#E1453#F10#;NA= ;TB=Basketball,#AS#B18#¬Germany Bundesliga,#ABM#B18#C20733749#D48#E1453#F10#;EN=1;FI=101299949;CC=BB;CK=20733749;DI=1001;NM=1;SO=1;OI=101299949;|MG;SY=cm;TB=1;|MA;NA=Lines;PD=#AC#B18#C20733749#D48#E1453#F10#;IT=ACB18C20733749D48E1453F10CC-MG-AGACB18C20733749D48E1453F10;LS=1;|MA;NA=Props;PD=#AC#B18#C20733749#D47#E181285#F47#;IT=ACB18C20733749D48E1453F10CC-MG-AGACB18C20733749D47E181285F47;|MA;NA=Futures;PD=#AC#B18#C20723202#D1#E55024570#F2#;IT=ACB18C20733749D48E1453F10CC-MG-AGACB18C20723202D1E55024570F2;|MG;ID=960;NA=Game Lines;SY=fa;PC=#AM#B18#C20733749#D48#E1453#F10#I0#;EN=2;IA=1;DO=1;OI=101299949;PI=1453,1454,960;CL=18;|MA;ID=M960;NA= ;FI=101299950;CN=1;SY=ef;PY=eib;|PA;ID=PC1617735499;NA=BBC Bayreuth;N2=Hamburg Towers;CU=;ED=;FD=BBC Bayreuth vs Hamburg Towers;FI=101299949;BC=20210429180000;FS=0;MR=221;VI=7;EX=puw~https://s5.sir.sportradar.com/bet365/en/match/23694455~Bet365Stats~Height=700,Width=1180,statusbar=yes,left=25,top=25,scrollbars=yes,resizable=1;CB=??#AN#DE#SU;ML=,,;PD=#AC#B18#C20733749#D19#E11618119#F19#;IT=ACB18C20733749D48E1453F10RCC-PA-AOACB18C20733749D19E11618119F19;KI=1;KC=#F0F0F0,#F0F0F0,#F0F0F0,#F0F0F0,#C40010,#0046A8,#3D4A4E;TX=1;TC=#0A0A0A,#F0F0F0,#F0F0F0,#F0F0F0,#C40010,#0046A8,#3D4A4E;|PA;FS=0;ML=,,;|PA;ID=PC1617735519;NA=Braunschweig;N2=S. Oliver Wurzburg;CU=;ED=;FD=Braunschweig vs S. Oliver Wurzburg;FI=101299953;BC=20210429180000;FS=0;MR=224;VI=7;EX=puw~https://s5.sir.sportradar.com/bet365/en/match/23694453~Bet365Stats~Height=700,Width=1180,statusbar=yes,left=25,top=25,scrollbars=yes,resizable=1;CB=??#AN#DE#SU;ML=,,;PD=#AC#B18#C20733749#D19#E11618120#F19#;IT=ACB18C20733749D48E1453F10RCC-PA-AOACB18C20733749D19E11618120F19;KI=1;KC=#FBED32,#FBED32,#FBED32,#FBED32,#C40010,#0046A8,#3D4A4E;TX=1;TC=#C40010,#C40010,#C40010,#C40010,#FF0000,#0000FF,#3D4A4E;|PA;FS=0;ML=,,;|PA;ID=PC1617735560;NA=Ratiopharm Ulm;N2=Crailsheim Merlins;CU=;ED=;FD=Ratiopharm Ulm vs Crailsheim Merlins;FI=101299956;BC=20210429193000;FS=0;MR=223;VI=7;EX=puw~https://s5.sir.sportradar.com/bet365/en/match/23694459~Bet365Stats~Height=700,Width=1180,statusbar=yes,left=25,top=25,scrollbars=yes,resizable=1;CB=??#AN#DE#SU;ML=,,;PD=#AC#B18#C20733749#D19#E11618121#F19#;IT=ACB18C20733749D48E1453F10RCC-PA-AOACB18C20733749D19E11618121F19;KI=1;KC=#FC7E00,#FC7E00,#FC7E00,#FC7E00,#C40010,#0046A8,#3D4A4E;TX=1;TC=#022857,#0A0A0A,#0A0A0A,#0A0A0A,#C40010,#0046A8,#3D4A4E;|PA;FS=0;ML=,,;|MA;ID=M960;NA=Spread;FI=101299950;CN=1;SY=eb;PY=asf;|PA;ID=1617735499;FI=101299949;HD=+3.5;HA=+3.5;OD=4*4;|PA;ID=1617735500;FI=101299949;HD=-3.5;HA=-3.5;OD=0*3;|PA;ID=1617735519;FI=101299953;HD=-3.5;HA=-3.5;OD=45*44;|PA;ID=1617735520;FI=101299953;HD=+3.5;HA=+3.5;OD=45*44;|PA;ID=1617735560;FI=101299956;HD=-6.5;HA=-6.5;OD=45*44;|PA;ID=1617735562;FI=101299956;HD=+6.5;HA=+6.5;OD=45*44;|MA;ID=M960;NA=Total;FI=101299950;CN=1;SY=eb;PY=asf;|PA;ID=1617735510;FI=101299952;HD=O 164.5;HA=164.5;OD=45*44;|PA;ID=1617735512;FI=101299952;HD=U 164.5;HA=164.5;OD=45*44;|PA;ID=1617735541;FI=101299955;HD=O 167.5;HA=167.5;OD=45*44;|PA;ID=1617735543;FI=101299955;HD=U 167.5;HA=167.5;OD=45*44;|PA;ID=1617735573;FI=101299958;HD=O 166.5;HA=166.5;OD=45*44;|PA;ID=1617735574;FI=101299958;HD=U 166.5;HA=166.5;OD=45*44;|MA;ID=M960;NA=Money Line;FI=101299950;CN=1;SY=eb;PY=asj;|PA;ID=1617735506;FI=101299950;OD=432*455;|PA;ID=1617735507;FI=101299950;OD=70*1=;|PA;ID=1617735525;FI=101299954;OD=1*2;|PA;ID=1617735526;FI=101299954;OD=64*75;|PA;ID=1617735567;FI=101299957;OD=0*41;|PA;ID=1617735568;FI=101299957;OD=76*45;|MA;ID=M960;NA= ;FI=101299950;CN=1;SY=em;PY=fi;|PA;ID=PC1617735499;NA=221;FI=101299949;PD=#AC#B18#C20733749#D19#E11618119#F19#P^48#Q^1453#;IT=ACB18C20733749D48E1453F10RCC-PA-AJACB18C20733749D19E11618119F19P48Q1453;|PA;SU=1;|PA;ID=PC1617735519;NA=224;FI=101299953;PD=#AC#B18#C20733749#D19#E11618120#F19#P^48#Q^1453#;IT=ACB18C20733749D48E1453F10RCC-PA-AJACB18C20733749D19E11618120F19P48Q1453;|PA;SU=1;|PA;ID=PC1617735560;NA=223;FI=101299956;PD=#AC#B18#C20733749#D19#E11618121#F19#P^48#Q^1453#;IT=ACB18C20733749D48E1453F10RCC-PA-AJACB18C20733749D19E11618121F19P48Q1453;|PA;SU=1;|MG;ID=LMAB;DO=1;SY=fc;CK=20733749;ED=Germany Bundesliga;PD=#PU#B18#C20733749#D48#E1453#F10#X4305#;IT=ACB18C20733749D48E1453F10CC-MG-AEPUB18C20733749D48E1453F10X4305;|"

result = result1
#point spread
def _xor(msg, key):
    value = ''
    for char in msg:
        value += chr(ord(char) ^ key)
    return value

TK = result.split(';')[1][3:]
key = ord(TK[0]) ^ ord(TK[1])

#get the market name
groups = result.split("|MG;ID=")[1]
market_name = groups.split(';')[1][3:]
print(market_name)

groups = result.split("|MG;")
_totalResult = []
k = 0

for event in groups:
    
    if event.startswith("ID="):
        
        if event.split(";")[1].startswith("NA="):
            continue
        
        event_name = None
        FI = None
        startTime = None

        #get the event id
        for _item in event.split(";"):
            if "NA=" in _item:
                event_name = _item[3:]
                break
        
        for _item in event.split(";"):
            if "FI=" in _item:
                FI = _item[3:]
                break

        if FI is None:
            continue

        for _item in event.split(";"):
            if "BC=" in _item:
                startTime = _item[3:]
                break

        date = parser.parse(startTime)
        date = date + timedelta(hours=9)
        _startTime = date.strftime("%Y-%m-%d %H:%M:%S")
        
        #print(event_name, FI, _startTime)

        #print("-----------------")
        #print(event)
        #print("-----------------")

        _selectionResult = []
        for _team in event.split("|MA;"):
            #print(_item)
            #print("-----")

            if "PA;" not in _team:
                continue
            
            title = None
            
            for _selection in _team.split("PA;"):
                try:
                    if "OD=" not in _selection:
                        for _item in _selection.split(';'):
                            if _item.startswith("NA="):
                                title = _item[3:]
                
                        continue

                    print(_selection)
                    print("-------")
                    selection_name = None
                    selection_id = None
                    selection_odds = None
                    
                    for _item in _selection.split(";"):
                        if "NA=" in _item:
                            selection_name = _item[3:]
                            break

                    for _item in _selection.split(";"):
                        if "ID=" in _item:
                            selection_id = _item[3:]
                            break

                    for _item in _selection.split(";"):
                        if "OD=" in _item:
                            selection_odds = _item[3:]
                            break
                                        
                    if selection_odds is not None and selection_odds != '':
                        n, d = _xor(selection_odds, key).split('/')
                        # it seem that is the conversion formula used by bet365 to
                        # convert from fractional to decimal format
                        odd = int((int(n) / int(d) + 1) * 100) * 10
                        selection_odds = odd
                        
                    print(selection_name, selection_id, selection_odds, title)
                    _selectionResult.append({
                        "selection_id": selection_id,
                        "selection_name": selection_name,
                        "title": title,
                        "odds": selection_odds,
                    })

                except Exception as f:
                    print(str(f))
        _totalResult.append({
            "event_name": event_name,
            "FI": FI,
            "startTime": _startTime,
            "selection": _selectionResult,
            "market_detail_name": None,
            "market_name": market_name
        })

def getValueFromList(_list, key):
    for item in _list:
        if item.startswith(key):
            return item[len(key):]
    return None

#game line type
if len(_totalResult) == 0:
    _resultE = []
    _resultO = []
    _detailMarketList = []
    groups = result.split("|MA;")
    for event in groups:
        

        if not event.startswith("ID="):
            continue
        
        #get the event
        if "OD=" not in event:
            for _pa in event.split("PA;"):
                if _pa.startswith("ID=") and "FD=" in _pa:
                    
                    _list = _pa.split(";")
                    event_name = getValueFromList(_list, "FD=")
                    startTime = getValueFromList(_list, "BC=")
                    team1 = getValueFromList(_list, "NA=")
                    team2 = getValueFromList(_list, "N2=")
                    team3 = getValueFromList(_list, "N3=")
                    FI = getValueFromList(_list, "FI=")
                    ID = getValueFromList(_list, "ID=")

                    date = parser.parse(startTime)
                    date = date + timedelta(hours=9)
                    _startTime = date.strftime("%Y-%m-%d %H:%M:%S")

                    _resultE.append({
                        "team1": team1,
                        "team2": team2,
                        "team3": team3,
                        "event_name": event_name,
                        "startTime": _startTime,
                        "FI": FI,
                        "ID": ID,
                    })
        
        #get the odds
        else:
            market_detail_name = getValueFromList(event.split(";"), "NA=")            
            _detailMarketList.append(market_detail_name)
            for _oddd in event.split("PA;"):
                if "OD=" not in _oddd:
                    continue
                
                _list = _oddd.split(";")
                ID = getValueFromList(_list, "ID=")
                HD = getValueFromList(_list, "HD=")
                FI = getValueFromList(_list, "FI=")
                HA = getValueFromList(_list, "HA=")
                OD = getValueFromList(_list, "OD=")

                if OD is not None and OD != '':
                    n, d = _xor(OD, key).split('/')
                    odd = int((int(n) / int(d) + 1) * 100) * 10
                    OD = odd
                
                _resultO.append({
                    "ID": ID,
                    "FI": FI,
                    "HD": HD,
                    "HA": HA,
                    "OD": OD,
                    "market_detail_name": market_detail_name
                })     

    _totalResult = []
    #match and set result
    for _event in _resultE:
        for _detail in _detailMarketList:
            param = {
                "event_name": _event["event_name"],
                "start_time": _event["startTime"],
                "FI": _event["FI"],
                "market": [],
                "market_name": market_name,
                "market_detail_name": _detail                
            }
            
            _list = []
            team = None

            count = 0
            for _odd in _resultO:
                if _odd["FI"] == _event["FI"]:
                    count = count + 1
                    if count == 1:
                        team = _event["team1"]
                    elif count == 2:
                        team = _event["team2"]
                    else:
                        team = _event["team3"]

                    _list.append({
                        "selection_name": team,
                        "selection_id": _odd['ID'],
                        "hd": _odd["HD"],
                        "OD": _odd["OD"]
                    })
            param["market"] = _list
        _totalResult.append(param)


print(_totalResult)

#print(len(_totalResult))
# market_name = groups.split(';')[1][3:]

# print("------------------------------market name------------------------")
# print(market_name)
# #get the team name
# groups = result.split("|MA;ID=")[1]
# groups = groups.split("PA;")
# _result = []
# for group in groups:
#     if "NA=" in group and "N2=" in group:
#         #print(group)
        
#         team1 = None
#         team2 = None
#         startTime = None
#         link = None
#         FI = None
#         team3 = None
#         #print(group)
#         for _item in group.split(";"):
#             if "NA=" in _item:
#                 team1 = _item[3:]
#                 break

#         for _item in group.split(";"):
#             if "N2=" in _item:
#                 team2 = _item[3:]
#                 break
        
#         for _item in group.split(";"):
#             if "N3=" in _item:
#                 team3 = _item[3:]
#                 break

#         for _item in group.split(";"):
#             if "BC=" in _item:
#                 startTime = _item
#                 break

#         for _item in group.split(";"):
#             if "PD=" in _item:
#                 link = _item[3]
#                 break

#         for _item in group.split(";"):
#             if "FI=" in _item:
#                 FI = _item[3:]
#                 break
                
#         date = parser.parse(startTime[3:])
#         date = date + timedelta(hours=9)
#         _startTime = date.strftime("%Y-%m-%d %H:%M:%S")
        
#         #print(team1,":", team2,":",team3,":", _startTime,":",link, FI)
#         _result.append({
#             "team1": team1,
#             "team2": team2,
#             "team3": team3,
#             "FI": FI,
#         })
# print("--------------------------Team--------------------")
# print(_result)

# #market info (per subname)
# TK = result.split(';')[1][3:]
# key = ord(TK[0]) ^ ord(TK[1])

# _oddResult = []
# groups = result.split("|MA;ID=")
# for group in groups:    
#     if not group.split(";")[1].startswith("NA="):
#         continue
                
#     marketSubName = None
#     for _item in group.split(";"):
#         if "NA=" in _item:
#             marketSubName = _item[3:]
#             break
    
#     #print(marketSubName)
#     if len(marketSubName) == 1:
#         continue

#     oddslist = group.split("|PA;")
    
#     for odds in oddslist:
#         #print(odds)
#         ID = None
#         FI = None
#         HD = None
#         OD = None

#         for _item in odds.split(";"):
#             if "ID=" in _item:
#                 ID = _item[3:]
#                 break

#         for _item in odds.split(";"):
#             if "FI=" in _item:
#                 FI = _item[3:]
#                 break
        
#         for _item in odds.split(";"):
#             if "HD=" in _item:
#                 HD = _item[3:]
#                 break

#         for _item in odds.split(";"):
#             if "OD=" in _item:
#                 OD = _item[3:]
#                 break
        
#         if OD is not None and OD != '':
#             n, d = _xor(OD, key).split('/')
#             # it seem that is the conversion formula used by bet365 to
#             # convert from fractional to decimal format
#             odd = int((int(n) / int(d) + 1) * 100) * 10
#             OD = odd

#         if ID is not None:
#             _oddResult.append({
#                 "event_id": FI,
#                 "handicap": HD,
#                 "price": OD,
#                 "selection_ID": ID,
#                 "market_subname": marketSubName,
#                 "market_name": market_name
#             })
# #print("------------------------------Result----------------------------")
# #print(_oddResult)