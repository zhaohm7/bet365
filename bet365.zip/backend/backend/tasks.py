from .utils import get_current_time_string
from .models import SportsInfo
from .models import Bet365Event, Bet365MarketInfo
from .serializers import SportsInfoSerializer
from .serializers import Bet365EventSerializer, Bet365MarketInfoSerializer
from celery import shared_task
import requests
from multiprocessing.dummy import Pool as ThreadPool 
import threading
from .difflib import SequenceMatcher
from dateutil import parser
from dateutil import tz
import pytz, json
from lxml import html
import re
from pyparsing import (Literal, CaselessLiteral, Word, Combine, Group, Optional,
                       ZeroOrMore, Forward, nums, alphas, oneOf)
import math
import operator
import random
from django.conf import settings
from datetime import datetime, timedelta, timezone
import time
from peewee import *
class NumericStringParser(object):
    '''
    Most of this code comes from the fourFn.py pyparsing example

    '''

    def pushFirst(self, strg, loc, toks):
        self.exprStack.append(toks[0])

    def pushUMinus(self, strg, loc, toks):
        if toks and toks[0] == '-':
            self.exprStack.append('unary -')

    def __init__(self):
        """
        expop   :: '^'
        multop  :: '*' | '/'
        addop   :: '+' | '-'
        integer :: ['+' | '-'] '0'..'9'+
        atom    :: PI | E | real | fn '(' expr ')' | '(' expr ')'
        factor  :: atom [ expop factor ]*
        term    :: factor [ multop factor ]*
        expr    :: term [ addop term ]*
        """
        point = Literal(".")
        e = CaselessLiteral("E")
        fnumber = Combine(Word("+-" + nums, nums) +
                          Optional(point + Optional(Word(nums))) +
                          Optional(e + Word("+-" + nums, nums)))
        ident = Word(alphas, alphas + nums + "_$")
        plus = Literal("+")
        minus = Literal("-")
        mult = Literal("*")
        div = Literal("/")
        lpar = Literal("(").suppress()
        rpar = Literal(")").suppress()
        addop = plus | minus
        multop = mult | div
        expop = Literal("^")
        pi = CaselessLiteral("PI")
        expr = Forward()
        atom = ((Optional(oneOf("- +")) +
                 (ident + lpar + expr + rpar | pi | e | fnumber).setParseAction(self.pushFirst))
                | Optional(oneOf("- +")) + Group(lpar + expr + rpar)
                ).setParseAction(self.pushUMinus)
        # by defining exponentiation as "atom [ ^ factor ]..." instead of
        # "atom [ ^ atom ]...", we get right-to-left exponents, instead of left-to-right
        # that is, 2^3^2 = 2^(3^2), not (2^3)^2.
        factor = Forward()
        factor << atom + \
            ZeroOrMore((expop + factor).setParseAction(self.pushFirst))
        term = factor + \
            ZeroOrMore((multop + factor).setParseAction(self.pushFirst))
        expr << term + \
            ZeroOrMore((addop + term).setParseAction(self.pushFirst))
        # addop_term = ( addop + term ).setParseAction( self.pushFirst )
        # general_term = term + ZeroOrMore( addop_term ) | OneOrMore( addop_term)
        # expr <<  general_term
        self.bnf = expr
        # map operator symbols to corresponding arithmetic operations
        epsilon = 1e-12
        self.opn = {"+": operator.add,
                    "-": operator.sub,
                    "*": operator.mul,
                    "/": operator.truediv,
                    "^": operator.pow}
        self.fn = {"sin": math.sin,
                   "cos": math.cos,
                   "tan": math.tan,
                   "exp": math.exp,
                   "abs": abs,
                   "trunc": lambda a: int(a),
                   "round": round,
                   "sgn": lambda a: abs(a) > epsilon and cmp(a, 0) or 0}

    def evaluateStack(self, s):
        op = s.pop()
        if op == 'unary -':
            return -self.evaluateStack(s)
        if op in "+-*/^":
            op2 = self.evaluateStack(s)
            op1 = self.evaluateStack(s)
            return self.opn[op](op1, op2)
        elif op == "PI":
            return math.pi  # 3.1415926535
        elif op == "E":
            return math.e  # 2.718281828
        elif op in self.fn:
            return self.fn[op](self.evaluateStack(s))
        elif op[0].isalpha():
            return 0
        else:
            return float(op)

    def eval(self, num_string, parseAll=True):
        self.exprStack = []
        results = self.bnf.parseString(num_string, parseAll)
        val = self.evaluateStack(self.exprStack[:])
        return val

def _xor(msg, key):
    value = ''
    for char in msg:
        value += chr(ord(char) ^ key)
    return value

def getValueFromList(_list, key):
    for item in _list:
        if item.startswith(key):
            return item[len(key):]
    return None

def getEventInfo(_result, _type):
    result = []
    try:
        items = re.split('SY=rsa;PY=rsa;|SY=rsr;PY=rsb;|SY=rsa;PY=rsp;',_result)

        count = -1
        for item in items:
            try:
                count = count + 1
                if count == 0:
                    continue

                races = item.split('PA;NA=')
                meeting_name = races[0].split(';')[0].replace('NA=','')                    
                
                c = 0
                for race in races:                    
                    try:
                        c = c + 1

                        if c == 1:
                            continue
                        
                        race = race.split(";|")[0]

                        infos = race.split(";")

                        event_no = infos[0]
                        link = None
                        starttime = None

                        for info in infos:
                            if "PD=" in info:
                                link = info[3:]

                            if "SM=" in info:
                                starttime = info[3:]                                                    

                        if event_no.isnumeric() == False:
                            continue

                        if starttime is not None:
                            date = parser.parse(starttime)
                            date = date + timedelta(hours=10)
                            starttime = date.strftime("%Y-%m-%d %H:%M:%S")
                        
                        if starttime is None:
                            continue                                          

                        result.append({
                            "event_url": link,
                            "startTime": starttime,
                            "event_no": event_no,
                            "updateTime": get_current_time_string(),
                            "event_title": meeting_name,
                            "event_type": _type,
                        })
                        
                    except Exception as f:                        
                        pass
            except Exception as k:                
                pass
            
    except Exception as g:        
        pass

    return result

def getBet365Cookie(sportsname):
    try:
        tz = pytz.timezone(settings.TIME_ZONE)
        from_time = (datetime.now(tz) - timedelta(minutes=3)).strftime("%Y-%m-%d %H:%M:%S")
        SportsInfo.objects.filter(sportsName=sportsname).filter(update_time__lte=from_time).delete()

        _record = SportsInfo.objects.filter(sportsName=sportsname).order_by('-update_time')
        _serial = SportsInfoSerializer(_record,many=True)
        result = []
        for item in _serial.data:
            try:
                if item["token"] is not None and item["cookie"] is not None:
                    result.append({
                        "cookie": item["cookie"],
                        "token": item["token"],
                    })
            except:
                pass
        return result
    except:
        return []
    
def getMarketInfo(_info):

    try:        

        headers = {
            "Host": "www.28365-365.com",
            "Connection": "keep-alive",
            "Cache-Control": "max-age=0",        
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36",            
            "Referer": "https://www.28365-365.com/",            
            'Cookie': _info["cookie"],
            "X-Net-Sync-Term": _info["token"]
        }

        urls = _info["event_url"]
        urls = urls.replace('#G1','')
        a = urls.split('#')
        a.insert(len(a) -2, 'G1')
        urls_1 = '#'.join(a)       

        url_1 = "https://www.28365-365.com/SportsBook.API/web?lid=30&zid=0&pd=" + (urls+"X^T#").replace('#','%23') + "&cid=13&cgid=1&ctid=13"
        url_2 = "https://www.28365-365.com/SportsBook.API/web?lid=30&zid=0&pd=" + (urls_1+"X^T#").replace('#','%23') + "&cid=13&cgid=1&ctid=13"

        session = requests.Session()

        session.get(url_1, headers=headers)
        session.get(url_2, headers=headers)

        response = session.get(url_1, headers=headers)
        
        results = response.text        
        results = results.replace("\"","")
        items = results.split("|MA;")

        _result = []
        for item in items:
            try:
                if "ID=" not in item:
                    continue
                
                horses = item.split("PA;")
                for horse in horses:
                    try:                
                        
                        if "FW=" not in horse and "OD=" not in horse:
                            continue
                        
                        _list = horse.split(";")
                        NA = getValueFromList(_list, "NA=")
                        
                        ID = getValueFromList(_list, "ID=")
                        FW = getValueFromList(_list, "FW=")
                        FP = getValueFromList(_list, "FP=")                
                        EX = getValueFromList(_list, "EX=")
                        PN = getValueFromList(_list, "PN=")
                        OD = getValueFromList(_list, "OD=")

                        if EX is None:
                            if FW is not None:
                                f = re.split(':|,', FW)                    
                                try:
                                    if f[0] != 'SP':
                                        nsp = NumericStringParser()
                                        result = nsp.eval(f[0]) + 1                            
                                        FW = result
                                    else:
                                        FW = 0

                                except Exception as f:
                                    FW = 0
                                    pass
                            
                            if FP is not None:
                                f = re.split(':|,', FP)                    
                                try:
                                    if f[0] != 'SP':
                                        nsp = NumericStringParser()
                                        result = nsp.eval(f[0]) + 1                            
                                        FP = "{:.2f}".format(result)
                                    else:
                                        FP = 0

                                except Exception as f:                                    
                                    FP = 0
                                    pass

                            if OD is not None:
                                f = re.split(':|,', OD)                    
                                try:
                                    if f[0] != 'SP':
                                        nsp = NumericStringParser()
                                        result = nsp.eval(f[0]) + 1                            
                                        OD = "{:.2f}".format(result)
                                except Exception as f:
                                    #print(str(f))
                                    pass    
                        else:
                            FW = 0
                            FP = 0
                        
                        _result.append({
                            "ID": ID,
                            "FW": FW,
                            "FP": FP,
                            "NA": NA,
                            "NO": PN,
                            "OD": OD
                        })

                    except Exception as f:                        
                        pass
            except:
                pass    
        
        if len(_result) == 0:
            print("no result---------------------", _info)
            return        

        a = _info["startTime"].split(' ')[0]
        s = Bet365Event.objects.get(event_no=_info["event_no"], event_title=_info["event_title"], event_type=_info["event_type"], startTime__contains=a)        
        #s.horse.clear()
        #save the market info
        for item in _result:
            try:
                if item["NA"] == "Favourite" or item["NA"] == "2nd Favourite":
                    continue

                count = Bet365MarketInfo.objects.filter(horse_id=item["ID"]).count()
                #print("count", count, item)
                if count == 0:
                    #insert
                    r = Bet365MarketInfo(name=item["NA"],horse_id=item["ID"],fixed_win=item["FW"], fixed_place=item["FP"], horse_no=item["NO"], updateTime=get_current_time_string(), fixed_odds=item["OD"])
                    r.save()       

                    s.horse.add(r)
                    #s.save()             
                else:                    
                    param = {}
                    if item["OD"] is None:
                        param = {
                            "fixed_win": item["FW"],
                            "fixed_place": item["FP"],                            
                            "updateTime": get_current_time_string()
                        }                    
                    else:
                        param = {                            
                            "fixed_odds": item["OD"],
                            "updateTime": get_current_time_string()
                        }   
                    #print("updated", param)                 
                    Bet365MarketInfo.objects.filter(horse_id=item["ID"]).update(**param)

            except Exception as f: 
                print(str(f),443)
                pass
        s.save()  
    except Exception as f:       
        print(str(f),123) 
        pass

workingFlag = False
@shared_task
def scrape_bet365_odds():
    global workingFlag
    if workingFlag == True:
        return

    workingFlag = True

    try:        
        tz = pytz.timezone(settings.TIME_ZONE)
        to_time = (datetime.now(tz) + timedelta(minutes=40)).strftime("%Y-%m-%d %H:%M:%S")
        from_time = (datetime.now(tz) - timedelta(seconds=30)).strftime("%Y-%m-%d %H:%M:%S")
        
        record = Bet365Event.objects.filter(startTime__gte=from_time).filter(startTime__lte=to_time).order_by('startTime')
        serial = Bet365EventSerializer(record, many=True)

        cookieList = getBet365Cookie("bet365_1")

        if cookieList == [] or len(cookieList) == 0:
            workingFlag = False
            return

        _result = []
        c = 0
        
        for item in serial.data:            
            _result.append({
                "event_url": item['event_url'],
                "event_title": item['event_title'],
                "event_no": item['event_no'],
                "event_type": item['event_type'],
                "startTime": item['startTime'],
                "cookie": cookieList[c % len(cookieList)]["cookie"],
                "token": cookieList[c % len(cookieList)]["token"]
            })                
            c = c + 1
                
        pool = ThreadPool(2)
        pool.starmap(getMarketInfo, zip(_result))
        pool.close()
        pool.join()
                
    except Exception as f:        
        pass

    workingFlag = False
    
@shared_task
def scrape_bet365_event():
    tz = pytz.timezone(settings.TIME_ZONE)

    #remove prev events info
    from_time = (datetime.now(tz) - timedelta(minutes=5)).strftime("%Y-%m-%d %H:%M:%S")    
    events = Bet365Event.objects.filter(startTime__lte=from_time)
    try:
        for item in events:
            for it in item.horse:
                it.delete()
    except Exception as f:
        print(str(f))
    Bet365Event.objects.filter(startTime__lte=from_time).delete()    

    from_time = (datetime.now(tz) - timedelta(hours=1)).strftime("%Y-%m-%d %H:%M:%S")
    Bet365MarketInfo.objects.filter(updateTime__lte=from_time).delete()    

    cookieList = getBet365Cookie("bet365_3")
    if cookieList == [] or len(cookieList) == 0:        
        return

    cookie = None
    token = None

    r = random.randint(0,len(cookieList)-1)
    cookie = cookieList[r]["cookie"]
    token = cookieList[r]["token"]

    headers = {
        "Host": "www.28365-365.com",
        "Connection": "keep-alive",
        "Cache-Control": "max-age=0",                
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4389.114 Safari/537.36",                
        "Referer": "https://www.28365-365.com/",                
        'Cookie': cookie,
        "X-Net-Sync-Term": token
    }

    #galloping        
    url = "https://www.28365-365.com/SportsBook.API/web?lid=30&zid=0&pd=%23AS%23B2%23&cid=13&cgid=1&ctid=13"                    
    session = requests.Session()
    response = session.get(url, headers=headers)            
    results = response.text        
    r_result = getEventInfo(results, "Galloping")

    #greyhounds
    url = "https://www.28365-365.com/SportsBook.API/web?lid=30&zid=0&pd=%23AS%23B4%23&cid=13&cgid=1&ctid=13"                    
    session = requests.Session()
    response = session.get(url, headers=headers)            
    results = response.text        
    g_result = getEventInfo(results, "Greyhounds")
    
    #harness
    url = "https://www.28365-365.com/SportsBook.API/web?lid=30&zid=0&pd=%23AS%23B88%23&cid=13&cgid=1&ctid=13"                    
    session = requests.Session()
    response = session.get(url, headers=headers)            
    results = response.text        
    h_result = getEventInfo(results, "Harness")

    _result = r_result + h_result + g_result    

    for item in _result:
        try:
            count = Bet365Event.objects.filter(event_no=item['event_no'],event_title=item['event_title'], event_type=item['event_type']).count()
            if count == 0:
                serial = Bet365EventSerializer(data=item)
                if serial.is_valid():
                    serial.save()                
            else:
                Bet365Event.objects.filter(event_no=item['event_no'],event_title=item['event_title'], event_type=item['event_type']).update(**item)
        except Exception as f:            
            pass    

    headers = {
        "Host": "www.28365-365.com",
        "Connection": "keep-alive",
        "Cache-Control": "max-age=0",                
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36",                
        "Referer": "https://www.28365-365.com/",                
        'Cookie': cookie,
        "X-Net-Sync-Term": token
    }    

    current_time = (datetime.now(tz) + timedelta(days=1)).strftime("%Y%m%d")

    #galloping
    url = "https://www.28365-365.com/SportsBook.API/web?lid=1&zid=3&pd=%23AS%23B2%23C103%23D" + current_time + "%23E0%23F0%23G0%23H0%23P13%23&cid=104&cgid=1&ctid=104"                    
    session = requests.Session()
    response = session.get(url, headers=headers)            
    results = response.text        
    r_result = getEventInfo(results, "Galloping")

    url = "https://www.28365-365.com/SportsBook.API/web?lid=1&zid=3&pd=%23AS%23B2%23C101%23D" + current_time + "%23E0%23F0%23G0%23H0%23P13%23&cid=104&cgid=1&ctid=104"
    session = requests.Session()
    response = session.get(url, headers=headers)            
    results = response.text        
    r_result_1 = getEventInfo(results, "Galloping")

    #greyhounds
    url = "https://www.28365-365.com/SportsBook.API/web?lid=1&zid=3&pd=%23AS%23B4%23C103%23D" + current_time + "%23E0%23F0%23G0%23H0%23P13%23&cid=104&cgid=1&ctid=104"                    
    session = requests.Session()
    response = session.get(url, headers=headers)            
    results = response.text        
    g_result = getEventInfo(results, "Greyhounds")

    url = "https://www.28365-365.com/SportsBook.API/web?lid=1&zid=3&pd=%23AS%23B4%23C101%23D" + current_time + "%23E0%23F0%23G0%23H0%23P13%23&cid=104&cgid=1&ctid=104"                    
    session = requests.Session()
    response = session.get(url, headers=headers)            
    results = response.text        
    g_result_1 = getEventInfo(results, "Greyhounds")
    
    #harness
    url = "https://www.28365-365.com/SportsBook.API/web?lid=1&zid=3&pd=%23AS%23B88%23C103%23D" + current_time + "%23E0%23F0%23G0%23H0%23P13%23&cid=104&cgid=1&ctid=104"
    session = requests.Session()
    response = session.get(url, headers=headers)            
    results = response.text        
    h_result = getEventInfo(results, "Harness")

    _result = r_result + r_result_1 + h_result + g_result + g_result_1
    
    for item in _result:
        try:
            count = Bet365Event.objects.filter(event_no=item['event_no'],event_title=item['event_title'], event_type=item['event_type']).count()
            if count == 0:
                serial = Bet365EventSerializer(data=item)
                if serial.is_valid():
                    serial.save()                
            else:
                Bet365Event.objects.filter(event_no=item['event_no'],event_title=item['event_title'], event_type=item['event_type']).update(**item)
        except Exception as f:
            pass

workingTormorrowFlag = False

@shared_task
def scrape_bet365_tomorrow_odds():
    global workingTormorrowFlag
    if workingTormorrowFlag == True:
        return
    workingTormorrowFlag = True
    try:        
        tz = pytz.timezone(settings.TIME_ZONE)

        #to_time = (datetime.now(tz) + timedelta(days=1)).strftime("%Y-%m-%d %H:%M:%S")
        from_time = (datetime.now(tz) + timedelta(minutes=40)).strftime("%Y-%m-%d %H:%M:%S")
        
        record = Bet365Event.objects.filter(startTime__gte=from_time).order_by('startTime')
        serial = Bet365EventSerializer(record, many=True)        

        _result = []
        c = 0

        cookieList = getBet365Cookie('bet365_2')
        if cookieList == [] or len(cookieList) == 0:
            workingTormorrowFlag = False
            return

        for item in serial.data:
            _result.append({
                "event_url": item['event_url'],
                "event_title": item['event_title'],
                "event_no": item['event_no'],
                "event_type": item['event_type'],
                "startTime": item['startTime'],
                "cookie": cookieList[c % len(cookieList)]["cookie"],
                "token": cookieList[c % len(cookieList)]["token"]
            })              
            c = c + 1
            
        thread_list = []        

        pool = ThreadPool(3)
        pool.starmap(getMarketInfo, zip(_result))
        pool.close()
        pool.join()
                
    except Exception as f:        
        pass

    workingTormorrowFlag = False

sqlite_db = SqliteDatabase('C:\\bot\\recent.db')
sqlite_db.connect()

DB_RECENT_MEETINGS_UPDATE = 10
LATEST_EVENTS_DURATION = 5
EVENTS_DURATION = 40
EVENTS_COUNT = 300

CONVERTER = {
    'bangor': 'bangor on dee',
    'doncaster eve': 'doncaster',
    'harlow eve': 'harlow',
    'newcastle eve': 'harlow',
    'youghal eve': 'youghal',
    'haydock': 'haydock park',
    'wheeling island': 'wheeling',
    'mardi gras tri state': 'tri state',
	'caliente': 'caliente - matinee',
	'caliente eve': 'caliente - evening',
	'hipo chile': 'hipodromo chile',
    'club hipico': 'club hipico santiago',
    'palermo': 'hipodromo argentino de palermo',
    'southland eve': 'southland',
    'mardi gras tri state eve': 'tri state',
    'iowa eve': 'dubuque',
    'los alamitos racecourse': 'los alamitos',
    'bangor-on-dee': 'bangor on dee'
}

SPORTS = {
    "THOROUGHBRED": 'Galloping',
    "HARNESS": 'Harness',
    "GREYHOUND": 'Greyhounds'
}

class BaseModel(Model):
    class Meta:
        database = sqlite_db

class RecentEvents(BaseModel):
    json = TextField()
    update_time = DateTimeField()

sqlite_db.create_tables([RecentEvents, ])

def getRecentsFromAPI(spider_type):
    resp = requests.get("https://dw.betia.co/api/next_events?limit=%s" % EVENTS_COUNT)
    events = resp.json()['data']['events']
    return events

def getEvents(spider_type):
    aus_tz = pytz.timezone("Australia/Queensland")
    current = datetime.timestamp(datetime.now())  

    expired = True
    events = []

    # read meetings from db
    for data in RecentEvents.select():
        events = json.loads(data.json)
        diff = int(current) - datetime.timestamp(data.update_time)
        if diff < DB_RECENT_MEETINGS_UPDATE * 60:
            expired = False

    if len(RecentEvents.select()) == 0:
        RecentEvents.create(json='[]', update_time=datetime.now())

    # read recent meetings from api
    if expired:
        events = getRecentsFromAPI(spider_type)
        RecentEvents.update(json=json.dumps(events), update_time=datetime.now()).execute()

    response = []
    index = 0
    for event in events:
        index += 1
        diff = (event['start_time'] - int(current)) / 60
        if spider_type == '1' and diff > 0 and diff <= EVENTS_DURATION:
            response.append(event)
        elif spider_type != '1' and spider_type != '4' and diff > EVENTS_DURATION:
            response.append(event)

    # if spider_type == '2':
    #     response = response[:int(len(response) / 2)]
    # elif spider_type == '3':
    #     response = response[int(len(response) / 2) - 1:]

    return response

def uploadOdds(events, sis_feed):
    for event in events:
        for sis in sis_feed:
            venue = sis['event_title'].lower().replace(' eve', '').strip()

            if 'haydock' in venue and venue in event['meeting']['venue']['venue_name'].lower() and \
                SPORTS[event['meeting']['venue']['venue_type']] == sis['event_type'] and event['number'] == int(sis['event_no']):
                pass
                
            start_time = datetime.fromtimestamp(event['start_time'])
            start_times = []
            for index in range(-15, 15):
                if index < 0:
                    start_times.append((start_time - timedelta(minutes=abs(index))).strftime('%Y-%m-%d %H:%M:%S'))
                else:
                    start_times.append((start_time + timedelta(minutes=index)).strftime('%Y-%m-%d %H:%M:%S'))

            '''if 'doncaster' not in venue or 'doncaster' not in event['meeting']['venue']['venue_name'].lower():
                continue
            print (['ppp', event['meeting']['venue']['venue_name'].lower(), event['number']])'''

            if sis['startTime'] in start_times and SPORTS[event['meeting']['venue']['venue_type']] == sis['event_type'] and \
                (event['meeting']['name'].lower() == venue or \
                event['meeting']['venue']['venue_name'].lower() == venue or \
                (venue in CONVERTER.keys() and \
                (event['meeting']['name'].lower() == CONVERTER[venue] or event['meeting']['venue']['venue_name'].lower() == CONVERTER[venue])) or venue in event['meeting']['venue']['venue_name'].lower()):
                # if event['number'] == int(sis['event_no']):
                res = extractOdd(event, sis, 'fixed_win')
                if res == False:
                    extractOdd(event, sis, 'fixed_odds')
                

def extractOdd(event, sis, odd_key):
    odds = dict()
    odds_win = []

    #print (sis)
    for horse in sis['horse']:
        if int(horse['horse_no']) > 30:
            continue
        try:
            if int(horse['horse_no']) not in odds.keys():
                odds[int(horse['horse_no'])] = round(float(horse[odd_key]), 2)
        except:
            odds[int(horse['horse_no'])] = 0.0

    if len(odds.keys()) == 0:
        return

    #print (odds.keys())
    for index in range(0, max(odds.keys())):
        index += 1
        if index not in odds.keys():
            odds[index] = 0.0

    #print (odds)
    for key in sorted(odds):
        try:
            odds_win.append(round(float(odds[key]), 2))
        except:
            odds_win.append(0.0)

    res = False
    for index in range(0, len(odds_win)):
        if odds_win[index] != 0:
            res = True
    
    if res:
        payload = {
            "meeting_id": event['meeting']['meeting_id'],
            "event_number": event['number'],
            "provider_id": 15,
            "provider_market_data": {
                
                "bet365": {
                    "WIN FX": {
                        "market": {
                            "prices": odds_win
                        }
                    }
                }
            }
        }
        #print (payload)
        requests.post("https://dw.betia.co/api/markets", data=json.dumps(payload))
        requests.post("https://dw-faye.betia.co/", headers={"Content-Type": "application/json"},
            json={"data": {'provider': 'bet365', 'id': event['event_id']}, "channel": "/odds_scrapers", "ext": {}})
    return res

workingRaceLabOdds = False
@shared_task
def scrape_racelabodds():
    global workingRaceLabOdds
    if workingRaceLabOdds == True:
        return
    workingRaceLabOdds = True    
    try:
        sis_feed = requests.get("http://localhost:8000/api/test/bet365").json()

        events = getEvents('1')
        uploadOdds(events, sis_feed)
    except:
        pass
    workingRaceLabOdds = False

workingRaceLabOdds2 = False
@shared_task
def scrape_racelabodds2():
    global workingRaceLabOdds2
    if workingRaceLabOdds2 == True:
        return
    workingRaceLabOdds2 = True    
    try:
        sis_feed = requests.get("http://localhost:8000/api/tom/bet365").json()

        events = getEvents('2')
        uploadOdds(events, sis_feed)
    except:
        pass
    workingRaceLabOdds2 = False










#betfred

def getCookie():
    record = SportsInfo.objects.filter(sportsName='BetFred')
    serial = SportsInfoSerializer(record, many=True)
    result = []
    for item in serial.data:
        try:
            if item["cookie"] is not None and len(item["cookie"]) != 0:
                result.append(item["cookie"])
        except:
            pass
    return result

def getBetfredEvent(url, _type):

    results = []

    try:            
        cookieList = getCookie()
        
        r = random.randint(0,2)
        cookie = cookieList[r]

        headers = {                
            "Referer": "https://www.betfred.com/sports/horses/today",                
            'Cookie': cookie,                
        }
                    
        session = requests.Session()
        response = session.get(url, headers=headers)
                    
        result = json.loads(response.text.encode('utf8'))
        
        to_zone = tz.gettz('Australia/Sydney')            

        for meeting in result["Racecourses"]:
            try:
                venue = meeting["Name"].upper().strip()
                for race in meeting["Races"]:
                    try:
                        eventId = race["EventId"]
                        _startTime = race["StartTimeIso"]
                        e = parser.parse(_startTime)
                        e = e - timedelta(hours=1)                            
                        startTime = e.astimezone(to_zone).strftime('%Y-%m-%d %H:%M:%S')

                        results.append({
                            "event_id": eventId,
                            "startTime": startTime,
                            "event_title": venue,
                            "updateTime": get_current_time_string(),
                            "event_type": _type
                        })
                    except Exception as f:
                        pass                  
            except Exception as f:
                print(str(f),"2")
    except Exception as f:
        print(str(f),"3")            

    return results

betflag = False
@shared_task
def scrape_betfred_event():
    global betflag
    if betflag == True:
        return
    betflag = True

    try:
        #remove prev events info
        tz = pytz.timezone(settings.TIME_ZONE)
        from_time = (datetime.now(tz) - timedelta(minutes=10)).strftime("%Y-%m-%d %H:%M:%S")
        BetFredEvent.objects.filter(startTime__lte=from_time).delete()

        url = 'https://www.betfred.com/services/horses/today?language=UK&region=440'
        result1 = getBetfredEvent(url, "Galloping")

        url = 'https://www.betfred.com/services/horses/tomorrow?language=UK&region=440'
        result2 = getBetfredEvent(url, "Galloping")

        url = 'https://www.betfred.com/services/greyhounds/today?language=UK&region=440'
        result3 = getBetfredEvent(url, "Greyhounds")

        _result = result1 + result2 + result3
        print("updated betfred event", len(_result))
        for item in _result:
            try:
                count = BetFredEvent.objects.filter(event_id=item['event_id']).count()
                if count == 0:
                    serial = BetFredEventSerializer(data=item)
                    if serial.is_valid():
                        serial.save()
                    else:
                        print(serial.errors)                    
                #else:
                    #BetFredEvent.objects.filter(event_title=item['event_title'],startTime=item['startTime']).update(**item)
            except Exception as f:
                print(str(f),333)     
    except Exception as f:
        print(str(f))
    betflag = False

def getBetFredMarketInfo(_info, _flag):
    try:
        cookieList = getCookie()
        
        r = 0

        cookie = None
        if _flag == True:
            r = random.randint(0,2)
            cookie = cookieList[r]            
        else:
            r = random.randint(3,7)
            cookie = cookieList[r]

        headers = {                
            "Referer": "https://www.betfred.com/sports/event/" + _info["event_id"],                
            'Cookie': cookie,                
            'Content-Type': 'application/json'
        }

        url = "https://www.betfred.com/services/SportsBook/event?language=uk&type=event&eventid=" + _info["event_id"] + "&dataflags=14&datasize=8"
        
        session = requests.Session()
        response = session.get(url, headers=headers)
        #print(response.text)
        result = json.loads(response.text.encode('utf8'))
        
        _result = []
        
        for item in result["Event"]["markets"][0]["selections"]:
            try:
                horseNo = "-"

                try:
                    horseNo = item["competitornumber"]
                except:
                    pass
                
                horseId = item["idfoselection"]
                horseName = item["name"]
                odds = 0
                try:
                    odds = float(item["currentpriceup"]) / float(item["currentpricedown"]) + 1                        
                    odds = "{:.2f}".format(odds)
                except:
                    pass

                _result.append({
                    "odds": odds,
                    "horse_no": horseNo,
                    "horse_id": horseId,
                    "horse_name": horseName
                })
            except:
                pass
        #save
        for item in _result:
            try:
                
                count = BetFredMarketInfo.objects.all().filter(horse_id=item["horse_id"]).count()
                
                if count == 0:
                    #insert
                    r = BetFredMarketInfo(name=item["horse_name"],horse_id=item["horse_id"],odds=item["odds"],horse_no=item["horse_no"], updateTime=get_current_time_string())
                    r.save()

                    s = BetFredEvent.objects.get(event_id=_info["event_id"])
                    s.horse.add(r)
                    s.save()
                else:
                    param = {
                        "odds": item["odds"],                            
                        "updateTime": get_current_time_string()
                    }
                    BetFredMarketInfo.objects.filter(horse_id=item["horse_id"]).update(**param)
                    #update
            except Exception as f:
                print(str(f),"2")
                pass

    except Exception as f:
        print(str(f))  

betFredMarketFlag = False     
@shared_task
def scrape_betfred_market():
    global betFredMarketFlag
    if betFredMarketFlag == True:
        return
    betFredMarketFlag = True
    try:
        tz = pytz.timezone(settings.TIME_ZONE)
        to_time = (datetime.now(tz) + timedelta(minutes=40)).strftime("%Y-%m-%d %H:%M:%S")
        from_time = datetime.now(tz).strftime("%Y-%m-%d %H:%M:%S")
        
        record = BetFredEvent.objects.filter(startTime__gte=from_time).filter(startTime__lte=to_time).order_by('startTime')
        serial = BetFredEventSerializer(record, many=True)

        _result = []
        for item in serial.data:
            _result.append({
                "event_id": item['event_id'],
                "event_title": item['event_title'],
                "startTime": item['startTime'],
                "event_type": item['event_type'],
            })
        
        for item in _result:
            getBetFredMarketInfo(item, True)
    except:
        pass
    betFredMarketFlag = False

fredTFlag = False     
@shared_task
def scrape_betfred_tomorrow_market():
    global fredTFlag
    if fredTFlag == True:
        return
    fredTFlag = True
    try:
        tz = pytz.timezone(settings.TIME_ZONE)
        to_time = (datetime.now(tz) + timedelta(minutes=40)).strftime("%Y-%m-%d %H:%M:%S")

        record = BetFredEvent.objects.filter(startTime__gte=to_time).order_by('startTime')
        serial = BetFredEventSerializer(record, many=True)

        _result = []
        for item in serial.data:
            _result.append({
                "event_id": item['event_id'],
                "event_title": item['event_title'],
                "startTime": item['startTime'],
                "event_type": item['event_type'],
            })
        
        for item in _result:
            getBetFredMarketInfo(item, False)
    except:
        pass
    fredTFlag = False
