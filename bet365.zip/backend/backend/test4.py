from dateutil import parser
import pytz
from datetime import datetime, timedelta
import re
from dateutil import tz
import random
result1 = "F|CL;ID=4;IT=#AC#B4#C101#D20211006#E20772537#F108934548#P12#X^T#;NA=Show Greyhounds Menu,Hide Greyhounds Menu;SY=8;NG=Sports/Greyhounds Coupon;NS=0;PV=2.0.1604.0/RacingCoupons;|EV;ID=EV;NA=Greyhounds;OR=0;EX=20211006192600#;CU=~;CM=@;TB=Greyhounds,#AS#B4#¬Sunderland EVE;EF=~;|MG;SY=ra;PF=1;IA=1;ML=;MI=;FS=0;RO=0;|MA;SY=ra;|PA;IT=RC_RMG_#AC#B4#C101#D20211006#E20772537#F108934548#P12#X^T#_#AA#B4#C101#D20211006#E20772537#F108934542#P12#;NA=1;PD=#AA#B4#C101#D20211006#E20772537#F108934542#P12#;|PA;IT=RC_RMG_#AC#B4#C101#D20211006#E20772537#F108934548#P12#X^T#_#AA#B4#C101#D20211006#E20772537#F108934543#P12#;NA=2;PD=#AA#B4#C101#D20211006#E20772537#F108934543#P12#;|PA;IT=RC_RMG_#AC#B4#C101#D20211006#E20772537#F108934548#P12#X^T#_#AA#B4#C101#D20211006#E20772537#F108934544#P12#;NA=3;PD=#AA#B4#C101#D20211006#E20772537#F108934544#P12#;|PA;IT=RC_RMG_#AC#B4#C101#D20211006#E20772537#F108934548#P12#X^T#_#AA#B4#C101#D20211006#E20772537#F108934545#P12#;NA=4;PD=#AA#B4#C101#D20211006#E20772537#F108934545#P12#;|PA;IT=RC_RMG_#AC#B4#C101#D20211006#E20772537#F108934548#P12#X^T#_#AC#B4#C101#D20211006#E20772537#F108934548#P12#;NA=5;PD=#AC#B4#C101#D20211006#E20772537#F108934548#P12#;LS=1;|PA;IT=RC_RMG_#AC#B4#C101#D20211006#E20772537#F108934548#P12#X^T#_#AC#B4#C101#D20211006#E20772537#F108934553#P12#;NA=6;PD=#AC#B4#C101#D20211006#E20772537#F108934553#P12#;|PA;IT=RC_RMG_#AC#B4#C101#D20211006#E20772537#F108934548#P12#X^T#_#AC#B4#C101#D20211006#E20772537#F108934562#P12#;NA=7;PD=#AC#B4#C101#D20211006#E20772537#F108934562#P12#;|PA;IT=RC_RMG_#AC#B4#C101#D20211006#E20772537#F108934548#P12#X^T#_#AC#B4#C101#D20211006#E20772537#F108934568#P12#;NA=8;PD=#AC#B4#C101#D20211006#E20772537#F108934568#P12#;|PA;IT=RC_RMG_#AC#B4#C101#D20211006#E20772537#F108934548#P12#X^T#_#AC#B4#C101#D20211006#E20772537#F108934572#P12#;NA=9;PD=#AC#B4#C101#D20211006#E20772537#F108934572#P12#;|PA;IT=RC_RMG_#AC#B4#C101#D20211006#E20772537#F108934548#P12#X^T#_#AC#B4#C101#D20211006#E20772537#F108934574#P12#;NA=10;PD=#AC#B4#C101#D20211006#E20772537#F108934574#P12#;|PA;IT=RC_RMG_#AC#B4#C101#D20211006#E20772537#F108934548#P12#X^T#_#AC#B4#C101#D20211006#E20772537#F108934578#P12#;NA=11;PD=#AC#B4#C101#D20211006#E20772537#F108934578#P12#;|PA;IT=RC_RMG_#AC#B4#C101#D20211006#E20772537#F108934548#P12#X^T#_#AC#B4#C101#D20211006#E20772537#F108934583#P12#;NA=12;PD=#AC#B4#C101#D20211006#E20772537#F108934583#P12#;|MA;IT=RC_RMG_#AC#B4#C101#D20211006#E20772537#F108934548#P12#X^T#_#ARM#B4#C101#D20211006;SY=rc;NA=7.26 Sunderland EVE;PD=#ARM#B4#C101#D20211006;EN=3;|MA;ID=CHROV108934548;SY=gre;CU=E/W 1/4 1-2~450m ~Best Odds Guaranteed;EF=~~2;N2=Race 5;PC=6;SM=20211006192600;FI=108934548;RO=0;LA=1;|MA;SY=gra;C1=20729251;C2=65849429;T1=5;T2=2;FI=108934548;VI=1;WB=0;ET=101;CB=AUHKSGUS;SV=0;TL=RC_CHROV_#AC#B4#C101#D20211006#E20772537#F108934548#P12#X^T#_;|MG;IT=RC_CHROV_#AC#B4#C101#D20211006#E20772537#F108934548#P12#X^T#_;SY=rn;IA=1;|MG;SY=rg;IA=1;|MA;IT=RC_TMBD_#AC#B4#C101#D20211006#E20772537#F108934548#P12#X^T#_#AC#B4#C101#D20211006#E20772537#F108934548#G1#P12#F^1;NA=Race Card;LS=1;PD=#AC#B4#C101#D20211006#E20772537#F108934548#G1#P12#F^1;|MA;IT=RC_TMBD_#AC#B4#C101#D20211006#E20772537#F108934548#P12#X^T#_#AC#B4#C101#D20211006#E20772537#F108934548#G100#P12#F^1;NA=Forecast / Tricast;PD=#AC#B4#C101#D20211006#E20772537#F108934548#G100#P12#F^1;LS=0;|MA;IT=RC_TMBD_#AC#B4#C101#D20211006#E20772537#F108934548#P12#X^T#_#AC#B4#C101#D20211006#E20772537#F108934548#G2#P12#F^1;NA=More Markets;PD=#AC#B4#C101#D20211006#E20772537#F108934548#G2#P12#F^1;LS=0;|MG;SY=rp;ST=4;DO=1;PF=1;IA=0;RO=0;ML=;FS=0;PT=;ID=131;CN=1;|MA;NA=Sort By Card:PN,Sort By Price:OD¬Last Run:LR;FE=1;IN=1;SY=grb;PY=gra;|PA;NA=Daisy Clover;ID=65234943;FI=108934548;NF=108934548;JN=;TN=;FO=1-2-6-T-T;OD=9/4;OH=3/1 ;SI=;HY=;SN=0;SU=0;HW=;LR=1-2-6-T-T;HI=29/09~450m [1]~1st~Bashful Kate~2/1F~A4~27.74~04.92~1111~1 1/4~rails, soon led~27.54~20#22/09~450m [2]~2nd~Bit View Cara~3/1~A4~28.26~05.10~5433~7 1/2~mid to rls, bmp1, ran on~27.45~20#16/09~450m [1]~6th~Kevs The Judge~11/2~A3~28.53~05.04~4343~8 1/4~mid to rls, clear run~27.69~20#12/09~450m [1]~3rd~Innfield Sam~~T3~28.39~05.07~2222~7 3/4~middle to rails, clear run~27.77~N#24/08~450m [1]~1st~Abigails Wagon~~T2~28.41~05.17~1111~HD~rails, always led, held on~28.31~10;FL=0;EW=1;BS=Trap 1;DI=866652;OR=1;PN=1;|PA;NA=Slap Dash;ID=65234949;FI=108934548;NF=108934548;JN=;TN=;FO=3-T-T-5-2;OD=6/1;OH=5/1 ;SI=;HY=;SN=0;SU=0;HW=;LR=3-T-T-5-2;HI=28/09~450m [2]~3rd~Bay City Pippa~15/2~A3~28.21~05.21~5553~4 3/4~mid to rails, clear run~27.63~20#22/09~450m [2]~1st~~~T1~27.90~05.06~0000~0~middle to rails~27.80~10#15/09~261m [2]~1st~~~T1~16.04~ ~0000~0~middle to rails~16.14~-10#03/08~450m [1]~5th~Saleen Matt~11/2~A3~28.43~05.24~6666~7 3/4~mid to rails, crowded1~27.71~10#28/07~450m [2]~2nd~Noelles Brazco~7/1~A3~28.20~05.10~3232~5 1/2~mid to rls, clear run~27.96~-20;FL=0;EW=1;BS=Trap 2;DI=919821;OR=2;PN=2;|PA;NA=Rafan Benz;ID=65234948;FI=108934548;NF=108934548;JN=;TN=;FO=5-1-5-T-3;OD=9/4;OH=;SI=;HY=;SN=0;SU=0;HW=;LR=5-1-5-T-3;HI=28/09~450m [2]~5th~Fenough Lark~11/2~A2~28.43~05.08~3334~10 3/4~mid to rls, crowded3~27.37~20#21/09~450m [2]~1st~Ballybrien Slick~5/2~A4~27.61~04.94~2111~2~mid to rls, led run up~27.41~20#15/09~450m [3]~5th~Coologue Uber~7/2~A3~28.49~05.08~3656~7 1/2~badly crowded 1/4~27.68~20#08/09~450m [2]~1st~Parish Adeus~~T3~28.06~05.10~1111~1~mid to rls, bmp& led1~28.36~-30#01/09~261m [2]~3rd~Bashful Belle~11/8F~D3~16.30~ ~5-3-~4 1/4~rails to middle, ran on~15.92~5;FL=0;EW=1;BS=Trap 3;DI=1005338;OR=3;PN=3;|PA;NA=Noirs Marilyn;ID=65234947;FI=108934548;NF=108934548;JN=;TN=;FO=1-1-2-5-T;OD=2/1;OH=;SI=;HY=;SN=0;SU=0;HW=;LR=1-1-2-5-T;HI=29/09~450m [3]~1st~Bit View Cara~11/4~A3~27.74~05.04~3332~HD~bumped start, led near line~27.54~20#22/09~450m [3]~1st~Ballycleary Kid~5/2J~A5~27.75~04.99~4443~1 1/4~mid, bmp1, led run in~27.55~20#08/09~450m [3]~2nd~Slippy Nell~11/4~A5~28.41~05.22~6554~2 1/2~middle, ran on~28.20~N#01/09~450m [3]~5th~Ushers Nick~9/2~A4~28.38~05.10~4355~6~middle, crowded1~27.90~N#25/08~450m [2]~1st~~~T1~28.13~05.05~0000~0~middle~27.93~20;FL=0;EW=1;BS=Trap 4;DI=1093568;OR=4;PN=4;|PA;NA=Strideaway Flash;ID=65234950;FI=108934548;NF=108934548;JN=;TN=;FO=1-4-2-5-6;OD=7/1;OH=6/1 ;SI=;HY=;SN=0;SU=0;HW=;LR=1-4-2-5-6;HI=28/09~450m [5]~1st~Dannys Eva~7/1~A4~27.84~05.09~1222~1 3/4~middle, led run in~27.74~10#16/09~450m [5]~4th~Kevs The Judge~10/1~A3~28.31~05.11~6556~5 1/4~lacked ep ace, mid, fcd t ck b3~27.69~20#12/09~450m [5]~2nd~Leamaneigh Ivy~14/1~A3~27.90~05.15~5545~1 1/2~middle, ran on late~27.78~N#07/09~450m [5]~5th~Derramore Blake~8/1~A3~28.49~05.16~6565~7 1/2~middle, crowded3~27.89~N#31/08~450m [5]~6th~Spitting Fire~13/2~A3~28.09~05.03~1466~4~early pace, mid, bmp 1/4~27.69~10;FL=0;EW=1;BS=Trap 5;DI=973708;OR=5;PN=5;|PA;NA=Mucho Macho Leah;ID=65234945;FI=108934548;NF=108934548;JN=;TN=;FO=5-5-5-6-6;OD=8/1;OH=;SI=;HY=;SN=0;SU=0;HW=;LR=5-5-5-6-6;HI=29/09~450m [6]~5th~Noirs Marilyn~17/2~A3~28.07~05.07~5665~4 1/4~mid to wide, fcd to ck1~27.54~20#23/09~450m [6]~5th~Hitthelids Kay~10/1~A3~28.27~05.05~4444~3~mid to wide, clear run~27.83~20#19/09~450m [6]~5th~Jackie Chaperal~14/1~A3~28.28~05.04~1555~6 1/4~mid to wide, baulked 1/4~27.68~10#12/09~450m [6]~6th~Leamaneigh Ivy~10/1~A3~28.34~05.10~4466~7~mid to wide, clear run~27.78~N#02/09~450m [5]~6th~Noirs Megan~18/1~A2~28.51~05.17~6666~10 1/4~mid to wide, crd 1/4, fcd to ck3~27.68~N;FL=0;EW=1;BS=Trap 6;DI=1003307;OR=6;PN=6;|PA;NA=Favourite;ID=65234944;FI=108934548;NF=108934548;JN=;TN=;FO=;OD=SP;OH=;SI=;HY=;SN=0;SU=0;HW=;FL=0;OR=99;PN=99;|MG;SY=ro;DO=0;NA=Race Overview;|MA;SY=ro;NA=NOIRS MARILYN arrives on the cusp of a hat-trick and Jackie Teal’s bitch appears capable of going faster than her recent times have suggested. DAISY CLOVER could see her odds come under pressure were Bashful Kate to run any sort of race in the opener. RAFAN BENZ could not cope with a double penalty for an A4 success so this compromise seems fair. STRIDEAWAY FLASH doesn’t do much quickly though she’s the noted closer in the pack tonight. Sels: 415;|"
result1 = "F|CL;ID=73;IT=#AC#B73#C104#D20211006#E20772560#F108937421#P12#X^T#;NA=Show US Horse Racing Menu,Hide US Horse Racing Menu;SY=8;NG=Sports/US Horse Racing Coupon;NS=0;PV=2.0.1604.0/RacingCoupons;|EV;ID=EV;NA=US Horse Racing;OR=0;EX=20211006201000#;ED=1;CU=~;CM=@;TB=Horse Racing,#AS#B2#¬Philadelphia;EF=~;|MG;SY=ra;PF=1;IA=1;ML=206782785658558442C2A_30/730079-206782785658558442C2A_30,206782785658558442C2A_30/730502-206782785658558442C2A_30,206782785658558442C2A_30/730503-206782785658558442C2A_30;MI=730079-730502-730503-;FS=0;RO=0;|MA;SY=ra;|PA;IT=RC_RMG_#AC#B73#C104#D20211006#E20772560#F108937421#P12#X^T#_#AA#B73#C104#D20211006#E20772560#F108937400#G1#H543#P12#;NA=1;PD=#AA#B73#C104#D20211006#E20772560#F108937400#G1#H543#P12#;|PA;IT=RC_RMG_#AC#B73#C104#D20211006#E20772560#F108937421#P12#X^T#_#AA#B73#C104#D20211006#E20772560#F108937410#G1#H543#P12#;NA=2;PD=#AA#B73#C104#D20211006#E20772560#F108937410#G1#H543#P12#;|PA;IT=RC_RMG_#AC#B73#C104#D20211006#E20772560#F108937421#P12#X^T#_#AA#B73#C104#D20211006#E20772560#F108937412#G1#H543#P12#;NA=3;PD=#AA#B73#C104#D20211006#E20772560#F108937412#G1#H543#P12#;|PA;IT=RC_RMG_#AC#B73#C104#D20211006#E20772560#F108937421#P12#X^T#_#AA#B73#C104#D20211006#E20772560#F108937414#G1#H543#P12#;NA=4;PD=#AA#B73#C104#D20211006#E20772560#F108937414#G1#H543#P12#;|PA;IT=RC_RMG_#AC#B73#C104#D20211006#E20772560#F108937421#P12#X^T#_#AC#B73#C104#D20211006#E20772560#F108937419#G1#H543#P12#;NA=5;PD=#AC#B73#C104#D20211006#E20772560#F108937419#G1#H543#P12#;|PA;IT=RC_RMG_#AC#B73#C104#D20211006#E20772560#F108937421#P12#X^T#_#AC#B73#C104#D20211006#E20772560#F108937421#G1#H543#P12#;NA=6;PD=#AC#B73#C104#D20211006#E20772560#F108937421#G1#H543#P12#;LS=1;|PA;IT=RC_RMG_#AC#B73#C104#D20211006#E20772560#F108937421#P12#X^T#_#AC#B73#C104#D20211006#E20772560#F108937422#G1#H543#P12#;NA=7;PD=#AC#B73#C104#D20211006#E20772560#F108937422#G1#H543#P12#;|PA;IT=RC_RMG_#AC#B73#C104#D20211006#E20772560#F108937421#P12#X^T#_#AC#B73#C104#D20211006#E20772560#F108937425#G1#H543#P12#;NA=8;PD=#AC#B73#C104#D20211006#E20772560#F108937425#G1#H543#P12#;|PA;IT=RC_RMG_#AC#B73#C104#D20211006#E20772560#F108937421#P12#X^T#_#AC#B73#C104#D20211006#E20772560#F108937432#G1#H543#P12#;NA=9;PD=#AC#B73#C104#D20211006#E20772560#F108937432#G1#H543#P12#;|PA;IT=RC_RMG_#AC#B73#C104#D20211006#E20772560#F108937421#P12#X^T#_#AC#B73#C104#D20211006#E20772560#F108937444#G1#H543#P12#;NA=10;PD=#AC#B73#C104#D20211006#E20772560#F108937444#G1#H543#P12#;|MA;IT=RC_RMG_#AC#B73#C104#D20211006#E20772560#F108937421#P12#X^T#_#ARM#B73#C104#D20211006;SY=rc;NA=Race 6 Philadelphia;PD=#ARM#B73#C104#D20211006;EN=3;|MA;ID=CHROV108937421;SY=rd;CU=E/W 1/4 1-2~6f Flat~Fast~Best Odds Guaranteed;EF=~~~2;N2=Race 6 Philadelphia;PC=6;SM=20211006201000;FI=108937421;RO=0;LA=1;|MA;SY=rf;RI=2$Win and each way only$20211006152945¬25p deduction pre {0};C1=20678278;C2=65855844;T1=5;T2=2;FI=108937421;VI=1;WB=0;ET=104;CB=AGAWBSBBKYCUDMDOGDHTJMKNLCVCTTUSUM;SV=0;TL=RC_CHROV_#AC#B73#C104#D20211006#E20772560#F108937421#P12#X^T#_;|MG;IT=RC_CHROV_#AC#B73#C104#D20211006#E20772560#F108937421#P12#X^T#_;SY=rn;IA=1;|MG;SY=rg;IA=1;|MA;IT=RC_TMBUS_#AC#B73#C104#D20211006#E20772560#F108937421#P12#X^T#_#AC#B73#C104#D20211006#E20772560#F108937421#G1#P12#F^1;ID=FixedOdds;NA=Race Card;LS=1;PD=#AC#B73#C104#D20211006#E20772560#F108937421#G1#P12#F^1;|MA;IT=RC_TMBUS_#AC#B73#C104#D20211006#E20772560#F108937421#P12#X^T#_#AC#B73#C104#D20211006#E20772560#F108937421#G102#P12#F^1;ID=Exotics;NA=Exotics;LS=0;PD=#AC#B73#C104#D20211006#E20772560#F108937421#G102#P12#F^1;|MG;SY=rp;ST=1;DO=1;PF=1;IA=1;RO=0;ML=206782785658558442C2A_30/730079-206782785658558442C2A_30,206782785658558442C2A_30/730502-206782785658558442C2A_30,206782785658558442C2A_30/730503-206782785658558442C2A_30;FS=0;PT=L73-20678278-5-65855844-2-20678278_30_0;ID=73000;CN=1;|MA;NA=Sort By Card:PN,Sort By Price:OD;FE=1;IN=0;SY=rha;PY=ru;|PA;NA=Baby Ice;ID=65495922;FI=108937421;NF=108937421;JN=Paco Lopez;TN=Scott Lake;FO=281116;OD=7/2;OH=4/1,5/1,13/2;SI=367670.GIF;HY=7;SN=1;SU=0;HW=124;HI=;FL=0;EW=1;BS=(1) Baby Ice;DI=148433;OR=1;PN=1;|PA;NA=Le Weekend;ID=65495926;FI=108937421;NF=108937421;JN=Ruben Silvera;TN=Jamie Ness;FO=231115;OD=13/8;OH=6/4,2/1,15/8;SI=404089.GIF;HY=7;SN=2;SU=0;HW=121;HI=;FL=0;EW=1;BS=(2) Le Weekend;DI=74791;OR=2;PN=2;|PA;NA=Fleeterthan;ID=65495925;FI=108937421;NF=108937421;JN=Andy Hernandez;TN=Michael Moore;FO=216384;OD=16/1;OH=16/1;SI=306862.GIF;HY=5;SN=3;SU=0;HW=121;HI=;FL=0;EW=1;BS=(3) Fleeterthan;DI=558686;OR=3;PN=3;|PA;NA=Enough Love;ID=65495923;FI=108937421;NF=108937421;JN=Wesley Torres;TN=Carlos Caban;FO=113266;OD=10/1;OH=12/1,12/1;SI=260549.GIF;HY=5;SN=4;SU=0;HW=121;HI=;FL=0;EW=1;BS=(4) Enough Love;DI=867830;OR=4;PN=4;|PA;NA=Madame Tiger;ID=65495927;FI=108937421;NF=108937421;JN=Mychel Sanchez;TN=Silvino Ramirez;FO=243441;OD=3/1;OH=11/2,5/1;SI=405942.GIF;HY=6;SN=5;SU=0;HW=121;HI=;FL=0;EW=1;BS=(5) Madame Tiger;DI=142423;OR=5;PN=5;|PA;NA=Miss Dillingham;ID=65495928;FI=108937421;NF=108937421;JN=Luis Rivera;TN=Michael Pino;FO=244413;OD=15/8;OH=3/1,10/3,4/1;SI=443314.GIF;HY=5;SN=7;SU=0;HW=124;HI=;FL=0;EW=1;BS=(7) Miss Dillingham;DI=328574;OR=7;PN=7;|PA;NA=Favourite;ID=65495924;FI=108937421;NF=108937421;JN=;TN=;FO=;OD=SP;OH=;SI=;HY=0;SN=0;SU=0;HW=;HI=;FL=0;OR=99;PN=99;|PA;NA=2nd Favourite;ID=65495921;FI=108937421;NF=108937421;JN=;TN=;FO=;OD=SP;OH=;SI=;HY=0;SN=0;SU=0;HW=;HI=;FL=0;OR=99;PN=99;|MA;SY=rs;NA=Non Runners;|PA;NA=Quality Stones;DI=872253;|"
from pyparsing import (Literal, CaselessLiteral, Word, Combine, Group, Optional,
                       ZeroOrMore, Forward, nums, alphas, oneOf)
import math
import operator

class NumericStringParser(object):
    '''
    Most of this code comes from the fourFn.py pyparsing example

    '''

    def pushFirst(self, strg, loc, toks):
        self.exprStack.append(toks[0])

    def pushUMinus(self, strg, loc, toks):
        if toks and toks[0] == '-':
            self.exprStack.append('unary -')

    def __init__(self):
        """
        expop   :: '^'
        multop  :: '*' | '/'
        addop   :: '+' | '-'
        integer :: ['+' | '-'] '0'..'9'+
        atom    :: PI | E | real | fn '(' expr ')' | '(' expr ')'
        factor  :: atom [ expop factor ]*
        term    :: factor [ multop factor ]*
        expr    :: term [ addop term ]*
        """
        point = Literal(".")
        e = CaselessLiteral("E")
        fnumber = Combine(Word("+-" + nums, nums) +
                          Optional(point + Optional(Word(nums))) +
                          Optional(e + Word("+-" + nums, nums)))
        ident = Word(alphas, alphas + nums + "_$")
        plus = Literal("+")
        minus = Literal("-")
        mult = Literal("*")
        div = Literal("/")
        lpar = Literal("(").suppress()
        rpar = Literal(")").suppress()
        addop = plus | minus
        multop = mult | div
        expop = Literal("^")
        pi = CaselessLiteral("PI")
        expr = Forward()
        atom = ((Optional(oneOf("- +")) +
                 (ident + lpar + expr + rpar | pi | e | fnumber).setParseAction(self.pushFirst))
                | Optional(oneOf("- +")) + Group(lpar + expr + rpar)
                ).setParseAction(self.pushUMinus)
        # by defining exponentiation as "atom [ ^ factor ]..." instead of
        # "atom [ ^ atom ]...", we get right-to-left exponents, instead of left-to-right
        # that is, 2^3^2 = 2^(3^2), not (2^3)^2.
        factor = Forward()
        factor << atom + \
            ZeroOrMore((expop + factor).setParseAction(self.pushFirst))
        term = factor + \
            ZeroOrMore((multop + factor).setParseAction(self.pushFirst))
        expr << term + \
            ZeroOrMore((addop + term).setParseAction(self.pushFirst))
        # addop_term = ( addop + term ).setParseAction( self.pushFirst )
        # general_term = term + ZeroOrMore( addop_term ) | OneOrMore( addop_term)
        # expr <<  general_term
        self.bnf = expr
        # map operator symbols to corresponding arithmetic operations
        epsilon = 1e-12
        self.opn = {"+": operator.add,
                    "-": operator.sub,
                    "*": operator.mul,
                    "/": operator.truediv,
                    "^": operator.pow}
        self.fn = {"sin": math.sin,
                   "cos": math.cos,
                   "tan": math.tan,
                   "exp": math.exp,
                   "abs": abs,
                   "trunc": lambda a: int(a),
                   "round": round,
                   "sgn": lambda a: abs(a) > epsilon and cmp(a, 0) or 0}

    def evaluateStack(self, s):
        op = s.pop()
        if op == 'unary -':
            return -self.evaluateStack(s)
        if op in "+-*/^":
            op2 = self.evaluateStack(s)
            op1 = self.evaluateStack(s)
            return self.opn[op](op1, op2)
        elif op == "PI":
            return math.pi  # 3.1415926535
        elif op == "E":
            return math.e  # 2.718281828
        elif op in self.fn:
            return self.fn[op](self.evaluateStack(s))
        elif op[0].isalpha():
            return 0
        else:
            return float(op)

    def eval(self, num_string, parseAll=True):
        self.exprStack = []
        results = self.bnf.parseString(num_string, parseAll)
        val = self.evaluateStack(self.exprStack[:])
        return val

def _xor(msg, key):
    value = ''
    for char in msg:
        value += chr(ord(char) ^ key)
    return value

def getValueFromList(_list, key):
    for item in _list:
        if item.startswith(key):
            return item[len(key):]
    return None

items = result1.split("|MA;")

_result = []
for item in items:
    try:
        # if not item.startswith("ID="):
        if "ID=" not in item:
            continue
        
        horses = item.split("PA;")
        for horse in horses:
            try:                
                
                if "FW=" not in horse and "OD=" not in horse:
                    continue                

                _list = horse.split(";")
                NA = getValueFromList(_list, "NA=")
                
                ID = getValueFromList(_list, "ID=")
                FW = getValueFromList(_list, "FW=")
                FP = getValueFromList(_list, "FP=")                
                EX = getValueFromList(_list, "EX=")
                PN = getValueFromList(_list, "PN=")
                OD = getValueFromList(_list, "OD=")

                if EX is None:
                    if FW is not None:
                        f = re.split(':|,', FW)                    
                        try:
                            if f[0] != 'SP':
                                nsp = NumericStringParser()
                                result = nsp.eval(f[0]) + 1                            
                                FW = result
                        except Exception as f:
                            print(str(f))
                            pass
                    
                    if FP is not None:
                        f = re.split(':|,', FP)                    
                        try:
                            if f[0] != 'SP':
                                nsp = NumericStringParser()
                                result = nsp.eval(f[0]) + 1                            
                                FP = "{:.2f}".format(result)
                        except Exception as f:
                            print(str(f))
                            pass

                    if OD is not None:
                        f = re.split(':|,', OD)                    
                        try:
                            if f[0] != 'SP':
                                nsp = NumericStringParser()
                                result = nsp.eval(f[0]) + 1                            
                                OD = "{:.2f}".format(result)
                        except Exception as f:
                            print(str(f))
                            pass    
                else:
                    FW = None
                    FP = None
                
                print(OD)
                _result.append({
                    "ID": ID,
                    "FW": FW,
                    "FP": FP,
                    "NA": NA,
                    "NO": PN,
                    "OD": OD
                })

            except Exception as f:
                print(str(f))
                pass
    except:
        pass

print(_result)



#AC#B4#C103#D20210809#E20761996#F106225981#P12#X^T#
#AC#B4#C103#D20210809#E20761996#F106225981#P13#

# https://www.bet365.com.au/SportsBook.API/web?lid=30&zid=0&pd=%23AC%23B4%23C103%23D20210809%23E20761996%23F106225982%23P12%23X%5ET%23&cid=13&cgid=1&ctid=13
# "https://www.bet365.com/SportsBook.API/web?lid=1&zid=3&pd=" + _info["event_url"].replace('#','%23') + "&cid=104&cgid=1&ctid=104"

# a = '"asdq'
# a = a.replace("\"","")
# print(a)

# a = "2021-08-21T18:00:00Z"
# e = parser.parse(a)

to_zone = tz.gettz('Australia/Sydney')
# f = e.astimezone(to_zone).strftime('%Y-%m-%d %H:%M:%S')
# print(f)

# d = "4"
# f = "3"

# e = float(d) / float(f) + 1
# h = "{:.2f}".format(e)
# print(e,h)

# a = "2021-08-21T18:00:00Z"
# e = parser.parse(a)          
# e = e + timedelta(hours=1)
# startTime = e.astimezone(to_zone).strftime('%Y-%m-%d %H:%M:%S')
# print(startTime)


# c = 0
# while True:
#     r = random.randint(3,7)            
#     print(r)
#     c = c+ 1
#     if c > 40:
#         break




b = "2021-09-08 22:22:00"
a = b.split(' ')[0]
print(a)



urls = "#AC#B2#C103#D20211007#E20772429#F108916932#G1#P12#"

urls = urls.replace('#G1','')
a = urls.split('#')
a.insert(len(a) -2, 'G1')
urls_1 = '#'.join(a)

print(urls)
print(urls_1)
