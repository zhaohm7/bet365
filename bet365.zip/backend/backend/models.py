from django.db import models
from datetime import datetime   
from django.contrib.auth.models import AbstractUser
from django.utils import timezone

class SportsInfo(models.Model):
    title = models.CharField(max_length=255)                                #Basketball    
    market_id = models.CharField(max_length=255)                            #16
    sportsName = models.CharField(max_length=255,null=True, blank=True)     #SportsBet
    token = models.CharField(max_length=255,null=True, blank=True)     
    cookie = models.TextField(null=True, blank=True)
    update_time = models.CharField(max_length=255, null=True, blank=True)
       
class Bet365MarketInfo(models.Model):
    name = models.CharField(max_length=255, blank=True, null=True, db_index=True)
    fixed_win = models.CharField(max_length=255, blank=True, null=True)
    fixed_place = models.CharField(max_length=255, blank=True, null=True)
    fixed_odds = models.CharField(max_length=255, blank=True, null=True)
    horse_id = models.CharField(max_length=255, db_index=True)
    horse_no = models.CharField(max_length=255, blank=True, null=True, db_index=True)
    updateTime = models.CharField(max_length=255, blank=True, null=True)

class Bet365Event(models.Model):
    event_no = models.CharField(max_length=255, db_index=True)              #1
    event_title = models.CharField(max_length=255, blank=True, null=True, db_index=True)   #FairView (SA)
    event_url = models.CharField(max_length=255, blank=True, null=True)     #url
    event_type = models.CharField(max_length=255, blank=True, null=True, db_index=True)    #Galloping
    startTime = models.CharField(max_length=255, blank=True, null=True, db_index=True)
    updateTime = models.CharField(max_length=255, blank=True, null=True)
    horse = models.ManyToManyField(Bet365MarketInfo, blank=True)    

### Betfred
class BetFredMarketInfo(models.Model):
    name = models.CharField(max_length=255, blank=True, null=True, db_index=True)
    horse_id = models.CharField(max_length=255, db_index=True, unique=True, blank=True)
    horse_no = models.CharField(max_length=255, blank=True, null=True, db_index=True)
    odds = models.CharField(max_length=255, blank=True, null=True)
    updateTime = models.CharField(max_length=255, blank=True, null=True)

class BetFredEvent(models.Model):
    event_id = models.CharField(max_length=255, db_index=True, unique=True)              #1
    event_title = models.CharField(max_length=255, blank=True, null=True, db_index=True)
    startTime = models.CharField(max_length=255, blank=True, null=True)
    event_type = models.CharField(max_length=255, blank=True, null=True, db_index=True)
    updateTime = models.CharField(max_length=255, blank=True, null=True)
    horse = models.ManyToManyField(BetFredMarketInfo, blank=True)