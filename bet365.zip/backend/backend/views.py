from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status, permissions
from django.http import HttpResponse
import json
from django.conf import settings
from datetime import datetime, timedelta, timezone
from django.contrib import auth
from rest_framework.authtoken.views import ObtainAuthToken
from rest_framework.authtoken.models import Token
from django.shortcuts import render
from .channel_util import send_alert
import time
from .utils import get_current_time_string
from .models import SportsInfo
from .models import Bet365Event, Bet365MarketInfo, BetFredEvent, BetFredMarketInfo
from .serializers import SportsInfoSerializer
from .serializers import Bet365EventSerializer, Bet365MarketInfoSerializer, BetFredEventSerializer, BetFredMarketInfoSerializer
import requests
from multiprocessing.dummy import Pool as ThreadPool 
import threading
from .difflib import SequenceMatcher
from dateutil import parser
import pytz
from lxml import html
import re
from pyparsing import (Literal, CaselessLiteral, Word, Combine, Group, Optional,
                       ZeroOrMore, Forward, nums, alphas, oneOf)
import math
import operator
import random
from dateutil import tz

class NumericStringParser(object):
    '''
    Most of this code comes from the fourFn.py pyparsing example

    '''

    def pushFirst(self, strg, loc, toks):
        self.exprStack.append(toks[0])

    def pushUMinus(self, strg, loc, toks):
        if toks and toks[0] == '-':
            self.exprStack.append('unary -')

    def __init__(self):
        """
        expop   :: '^'
        multop  :: '*' | '/'
        addop   :: '+' | '-'
        integer :: ['+' | '-'] '0'..'9'+
        atom    :: PI | E | real | fn '(' expr ')' | '(' expr ')'
        factor  :: atom [ expop factor ]*
        term    :: factor [ multop factor ]*
        expr    :: term [ addop term ]*
        """
        point = Literal(".")
        e = CaselessLiteral("E")
        fnumber = Combine(Word("+-" + nums, nums) +
                          Optional(point + Optional(Word(nums))) +
                          Optional(e + Word("+-" + nums, nums)))
        ident = Word(alphas, alphas + nums + "_$")
        plus = Literal("+")
        minus = Literal("-")
        mult = Literal("*")
        div = Literal("/")
        lpar = Literal("(").suppress()
        rpar = Literal(")").suppress()
        addop = plus | minus
        multop = mult | div
        expop = Literal("^")
        pi = CaselessLiteral("PI")
        expr = Forward()
        atom = ((Optional(oneOf("- +")) +
                 (ident + lpar + expr + rpar | pi | e | fnumber).setParseAction(self.pushFirst))
                | Optional(oneOf("- +")) + Group(lpar + expr + rpar)
                ).setParseAction(self.pushUMinus)
        # by defining exponentiation as "atom [ ^ factor ]..." instead of
        # "atom [ ^ atom ]...", we get right-to-left exponents, instead of left-to-right
        # that is, 2^3^2 = 2^(3^2), not (2^3)^2.
        factor = Forward()
        factor << atom + \
            ZeroOrMore((expop + factor).setParseAction(self.pushFirst))
        term = factor + \
            ZeroOrMore((multop + factor).setParseAction(self.pushFirst))
        expr << term + \
            ZeroOrMore((addop + term).setParseAction(self.pushFirst))
        # addop_term = ( addop + term ).setParseAction( self.pushFirst )
        # general_term = term + ZeroOrMore( addop_term ) | OneOrMore( addop_term)
        # expr <<  general_term
        self.bnf = expr
        # map operator symbols to corresponding arithmetic operations
        epsilon = 1e-12
        self.opn = {"+": operator.add,
                    "-": operator.sub,
                    "*": operator.mul,
                    "/": operator.truediv,
                    "^": operator.pow}
        self.fn = {"sin": math.sin,
                   "cos": math.cos,
                   "tan": math.tan,
                   "exp": math.exp,
                   "abs": abs,
                   "trunc": lambda a: int(a),
                   "round": round,
                   "sgn": lambda a: abs(a) > epsilon and cmp(a, 0) or 0}

    def evaluateStack(self, s):
        op = s.pop()
        if op == 'unary -':
            return -self.evaluateStack(s)
        if op in "+-*/^":
            op2 = self.evaluateStack(s)
            op1 = self.evaluateStack(s)
            return self.opn[op](op1, op2)
        elif op == "PI":
            return math.pi  # 3.1415926535
        elif op == "E":
            return math.e  # 2.718281828
        elif op in self.fn:
            return self.fn[op](self.evaluateStack(s))
        elif op[0].isalpha():
            return 0
        else:
            return float(op)

    def eval(self, num_string, parseAll=True):
        self.exprStack = []
        results = self.bnf.parseString(num_string, parseAll)
        val = self.evaluateStack(self.exprStack[:])
        return val

def _xor(msg, key):
    value = ''
    for char in msg:
        value += chr(ord(char) ^ key)
    return value

def getValueFromList(_list, key):
    for item in _list:
        if item.startswith(key):
            return item[len(key):]
    return None

def index(request):
    return render(request, 'index.html')

# signin
class CustomObtainAuthToken(ObtainAuthToken):
    def post(self, request, *args, **kwargs):
        response = super(CustomObtainAuthToken, self).post(request, *args, **kwargs)        
        token = Token.objects.get(key=response.data['token'])
        return Response({'token': token.key, 'id': token.user_id})

class SportsInfoView(APIView):
    permission_classes = ( permissions.IsAuthenticated, )
    #read
    def get(self, request):
        record = SportsInfo.objects.all()
        serial = SportsInfoSerializer(record, many=True)
        return Response(serial.data, status=status.HTTP_200_OK)
    
    #add
    def post(self, request):
        return Response(status=status.HTTP_200_OK)

    #delete
    def delete(self, request, pk):
        return Response(status=status.HTTP_200_OK)

    #update
    def put(self, request, pk):
        return Response(status=status.HTTP_200_OK)

class Bet365ToView(APIView):
    def get(self, request):
        tz = pytz.timezone(settings.TIME_ZONE)        
        from_time = (datetime.now(tz) + timedelta(minutes=40)).strftime("%Y-%m-%d %H:%M:%S")
        record = Bet365Event.objects.filter(startTime__gte=from_time).order_by('startTime')
        serial = Bet365EventSerializer(record, many=True)
            
        return Response(serial.data, status=status.HTTP_200_OK)

class Bet365View(APIView):
    def get(self, request):
        tz = pytz.timezone(settings.TIME_ZONE)
        to_time = (datetime.now(tz) + timedelta(minutes=40)).strftime("%Y-%m-%d %H:%M:%S")
        from_time = (datetime.now(tz) - timedelta(minutes=5)).strftime("%Y-%m-%d %H:%M:%S")        
        record = Bet365Event.objects.filter(startTime__gte=from_time).filter(startTime__lte=to_time).order_by('startTime')        
        serial = Bet365EventSerializer(record, many=True)
            
        return Response(serial.data, status=status.HTTP_200_OK)

    def getEventInfo(self, _result, _type):
        result = []
        try:
            items = re.split('SY=rsa;PY=rsa;|SY=rsr;PY=rsb;|SY=rsa;PY=rsp;',_result)

            count = -1
            for item in items:
                try:
                    count = count + 1
                    if count == 0:
                        continue

                    races = item.split('PA;NA=')
                    meeting_name = races[0].split(';')[0].replace('NA=','')                    
                    
                    c = 0
                    for race in races:
                        try:
                            c = c + 1
                            if c == 1:
                                continue

                            infos = race.split(";")

                            event_no = infos[0]
                            link = None
                            starttime = None

                            for info in infos:
                                if "PD=" in info:
                                    link = info[3:]

                                if "SM=" in info:
                                    starttime = info[3:]                                                    

                            if starttime is not None:
                                date = parser.parse(starttime)
                                date = date + timedelta(hours=9)
                                starttime = date.strftime("%Y-%m-%d %H:%M:%S")
                            
                            if starttime is None:
                                continue

                            result.append({
                                "event_url": link,
                                "startTime": starttime,
                                "event_no": event_no,
                                "updateTime": get_current_time_string(),
                                "event_title": meeting_name,
                                "event_type": _type,                                
                            })
                            
                        except Exception as f:
                            print(str(f))
                            pass
                except Exception as k:
                    print(str(k))
                    pass
                
        except Exception as g:
            print(str(g))
            pass

        return result

    #get the event info every 3 hours
    def post(self, request):
        record = SportsInfo.objects.filter(sportsName='Bet365')
        serial = SportsInfoSerializer(record,many=True)                        

        _token = None
        _cookie = None

        for _sport in serial.data: 
            _token = _sport["token"]    
            _cookie = _sport["cookie"]
            break
        
        headers = {
            "Host": "www.28365-365.com",
            "Connection": "keep-alive",
            "Cache-Control": "max-age=0",                
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36",                
            "Referer": "https://www.28365-365.com/",                
            'Cookie': _token,
            "X-Net-Sync-Term": _cookie
        }

        #galloping        
        url = "https://www.bet365.com.au/SportsBook.API/web?lid=1&zid=3&pd=%23AS%23B2%23&cid=99&cgid=1&ctid=99"                    
        session = requests.Session()
        response = session.get(url, headers=headers)            
        results = response.text        
        r_result = self.getEventInfo(results, "Galloping")

        #greyhounds
        url = "https://www.bet365.com.au/SportsBook.API/web?lid=1&zid=3&pd=%23AS%23B4%23&cid=99&cgid=1&ctid=99"                    
        session = requests.Session()
        response = session.get(url, headers=headers)            
        results = response.text        
        g_result = self.getEventInfo(results, "Greyhounds")
        
        #harness
        url = "https://www.bet365.com.au/SportsBook.API/web?lid=1&zid=3&pd=%23AS%23B88%23&cid=99&cgid=1&ctid=99"                    
        session = requests.Session()
        response = session.get(url, headers=headers)            
        results = response.text        
        h_result = self.getEventInfo(results, "Harness")

        _result = r_result + h_result + g_result

        for item in _result:
            try:
                count = Bet365Event.objects.filter(event_no=item['event_no'],event_title=item['event_title'], event_type=item['event_type'], startTime=item['startTime']).count()
                if count == 0:
                    serial = Bet365EventSerializer(data=item)
                    if serial.is_valid():
                        serial.save()
                    else:
                        print(serial.errors)                    
                else:
                    Bet365Event.objects.filter(event_no=item['event_no'],event_title=item['event_title']).update(**item)
            except Exception as f:
                print(str(f),333)     

        return Response(g_result, status=status.HTTP_200_OK)

    def put(self, request):
        try:
            tz = pytz.timezone(settings.TIME_ZONE)
            to_time = (datetime.now(tz) + timedelta(minutes=40)).strftime("%Y-%m-%d %H:%M:%S")
            from_time = (datetime.now(tz) - timedelta(minutes=5)).strftime("%Y-%m-%d %H:%M:%S")
            
            record = Bet365Event.objects.filter(startTime__gte=from_time).filter(startTime__lte=to_time).order_by('startTime')
            serial = Bet365EventSerializer(record, many=True)

            _result = []

            _record = SportsInfo.objects.filter(sportsName='Bet365')
            _serial = SportsInfoSerializer(_record,many=True)                        
            _result = []

            cookie = None
            token = None
            for _sport in _serial.data: 
                cookie = _sport['cookie']
                token = _sport['token']
                break
                
            for item in serial.data:
                _result.append({
                    "event_url": item['event_url'],
                    "event_title": item['event_title'],
                    "event_no": item['event_no'],
                    "event_type": item['event_type'],
                    "startTime": item['startTime'],
                    "cookie": cookie,
                    "token": token
                })                

            pool = ThreadPool(3)
            pool.starmap(self.getMarketInfo, zip(_result))
            pool.close()
            pool.join()
        except:
            pass
        return Response(status=status.HTTP_200_OK)

    def getMarketInfo(self, _info):
        try:

            headers = {
                "Host": "www.28365-365.com",
                "Connection": "keep-alive",
                "Cache-Control": "max-age=0",
                # "Upgrade-Insecure-Requests": "1",
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36",
                # "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
                "Referer": "https://www.28365-365.com/",
                # "Accept-Encoding": "gzip, deflate, br",
                # "Accept-Language": "en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7",
                'Cookie': _info['cookie'],
                "X-Net-Sync-Term": _info['token']
            }
            
            url = "https://www.bet365.com/SportsBook.API/web?lid=1&zid=3&pd=" + _info["event_url"].replace('#','%23') + "X%5EM%23&cid=104&cgid=1&ctid=104"
                        
            session = requests.Session()
            response = session.get(url, headers=headers)
            
            results = response.text
            results = results.replace("\"","")
            items = results.split("|MA;")

            _result = []
            for item in items:
                try:
                    if "ID=" not in item:
                        continue
                    
                    horses = item.split("PA;")
                    for horse in horses:
                        try:                
                            
                            if "FW=" not in horse and "OD=" not in horse:
                                continue
                            
                            print(horse)
                            print("\n")

                            _list = horse.split(";")
                            NA = getValueFromList(_list, "NA=")
                            
                            ID = getValueFromList(_list, "ID=")
                            FW = getValueFromList(_list, "FW=")
                            FP = getValueFromList(_list, "FP=")                
                            EX = getValueFromList(_list, "EX=")
                            PN = getValueFromList(_list, "PN=")
                            OD = getValueFromList(_list, "OD=")
                            
                            if EX is None:
                                if FW is not None:
                                    f = re.split(':|,', FW)                    
                                    try:
                                        if f[0] != 'SP':
                                            nsp = NumericStringParser()
                                            result = nsp.eval(f[0]) + 1                            
                                            FW = result
                                        else:
                                            FW = 0

                                    except Exception as f:
                                        print(str(f))
                                        FW = 0
                                        pass
                                
                                if FP is not None:
                                    f = re.split(':|,', FP)                    
                                    try:
                                        if f[0] != 'SP':
                                            nsp = NumericStringParser()
                                            result = nsp.eval(f[0]) + 1                            
                                            FP = "{:.2f}".format(result)
                                        else:
                                            FP = 0

                                    except Exception as f:
                                        print(str(f))
                                        FP = 0
                                        pass

                                if OD is not None:
                                    f = re.split(':|,', OD)                    
                                    try:
                                        if f[0] != 'SP':
                                            nsp = NumericStringParser()
                                            result = nsp.eval(f[0]) + 1                            
                                            OD = "{:.2f}".format(result)
                                    except Exception as f:
                                        print(str(f))
                                        pass    
                            else:
                                FW = 0
                                FP = 0
                            
                            _result.append({
                                "ID": ID,
                                "FW": FW,
                                "FP": FP,
                                "NA": NA,
                                "NO": PN,
                                "OD": OD
                            })

                        except Exception as f:
                            print(str(f))
                            pass
                except:
                    pass
        
            print(len(_result))
            #save the market info
            for item in _result:
                try:
                    count = Bet365MarketInfo.objects.filter(horse_id=item["ID"], name=item["NA"]).count()
                    if count == 0:
                        #insert
                        r = Bet365MarketInfo(name=item["NA"],horse_id=item["ID"],fixed_win=item["FW"], fixed_place=item["FP"], horse_no=item["NO"], updateTime=get_current_time_string())
                        r.save()

                        s = Bet365Event.objects.get(event_no=_info["event_no"],event_url=_info["event_url"],event_title=_info["event_title"],event_type=_info["event_type"], startTime=_info['startTime'])
                        s.horse.add(r)
                        s.save()
                    else:
                        param = {
                            "fixed_win": item["FW"],
                            "fixed_place": item["FP"],
                            "updateTime": get_current_time_string()
                        }
                        Bet365MarketInfo.objects.filter(horse_id=item["ID"], name=item["NA"]).update(**param)
                        #update
                except:
                    pass
        except:
            pass
        
class Bet365TokenView(APIView):
    def post(self, request):        
        # param = {
        #     "token": request.data['token']
        # }
        # SportsInfo.objects.filter(sportsName='Bet365').update(**param)
        # r = SportsInfo.objects.get(pk=pk)
        # r.token = request.data['token']
        # r.save()

        r = SportsInfo(cookie=request.data['cookie'], token=request.data['token'], update_time=get_current_time_string(),sportsName=request.data['sportsName'], title='Bet365', market_id='Bet365')
        r.save()

        return Response(status=status.HTTP_200_OK)

    # def post(self, request, pk):        
    #     # param = {
    #     #     "token": request.data['token']
    #     # }
    #     # SportsInfo.objects.filter(sportsName='Bet365').update(**param)
    #     r = SportsInfo.objects.get(pk=pk)
    #     r.token = request.data['token']
    #     r.save()
    #     return Response(status=status.HTTP_200_OK)

class Bet365CookieView(APIView):
    def post(self, request,pk):
        # param = {
        #     "cookie": request.data['cookie']
        # }
        # SportsInfo.objects.filter(sportsName='Bet365').update(**param)
        r = SportsInfo.objects.get(pk=pk)
        r.cookie = request.data['cookie']
        r.token = request.data['token']
        r.save()
        return Response(status=status.HTTP_200_OK)

class BetFredCookieView(APIView):
    def post(self, request, pk):
        param = {
            "cookie": request.data['cookie']
        }
        r = SportsInfo.objects.get(pk=pk)
        r.cookie = request.data['cookie']        
        r.save()
        #SportsInfo.objects.filter(sportsName='BetFred').update(**param)
        return Response(status=status.HTTP_200_OK)

class BetFredTomView(APIView):
    def get(self, request):
        tz = pytz.timezone(settings.TIME_ZONE)
        from_time = (datetime.now(tz) + timedelta(minutes=40)).strftime("%Y-%m-%d %H:%M:%S")
        
        record = BetFredEvent.objects.filter(startTime__gte=from_time).order_by('startTime')        
        serial = BetFredEventSerializer(record, many=True)
            
        return Response(serial.data, status=status.HTTP_200_OK)

class BetFredView(APIView):
    def getCookie(self):
        record = SportsInfo.objects.filter(sportsName='BetFred')
        serial = SportsInfoSerializer(record, many=True)
        result = []
        for item in serial.data:
            if item["cookie"] is not None and len(item["cookie"]) != 0:
                result.append(item["cookie"])
        return result

    def getEvent(self, url, _type):

        results = []

        try:            
            cookieList = self.getCookie()
            
            r = random.randint(0,len(cookieList)-1)
            cookie = cookieList[r]

            headers = {                
                "Referer": "https://www.betfred.com/sports/horses/today",                
                'Cookie': cookie,                
            }
                        
            session = requests.Session()
            response = session.get(url, headers=headers)
                        
            result = json.loads(response.text.encode('utf8'))
            print(response.text)
            to_zone = tz.gettz('Australia/Sydney')            

            for meeting in result["Racecourses"]:
                try:
                    venue = meeting["Name"].upper().strip()
                    for race in meeting["Races"]:
                        try:
                            eventId = race["EventId"]
                            _startTime = race["StartTimeIso"]
                            e = parser.parse(_startTime)
                            e = e - timedelta(hours=1)                            
                            startTime = e.astimezone(to_zone).strftime('%Y-%m-%d %H:%M:%S')

                            results.append({
                                "event_id": eventId,
                                "startTime": startTime,
                                "event_title": venue,
                                "updateTime": get_current_time_string(),
                                "event_type": _type
                            })
                        except Exception as f:
                            pass                  
                except Exception as f:
                    print(str(f),"2")
        except Exception as f:
            print(str(f),"3")            

        return results

    def post(self, request):
        try:
            url = 'https://www.betfred.com/services/horses/today?language=UK&region=440'
            result1 = self.getEvent(url, "Galloping")

            url = 'https://www.betfred.com/services/greyhounds/today?language=UK&region=440'
            result2 = self.getEvent(url, "Greyhounds")

            _result = result1 + result2

            for item in _result:
                try:
                    count = BetFredEvent.objects.filter(event_title=item['event_title'], event_type=item['event_type'], startTime=item['startTime']).count()
                    if count == 0:
                        serial = BetFredEventSerializer(data=item)
                        if serial.is_valid():
                            serial.save()
                        else:
                            print(serial.errors)                    
                    #else:
                        #BetFredEvent.objects.filter(event_title=item['event_title'],startTime=item['startTime']).update(**item)
                except Exception as f:
                    print(str(f),333)     
        except Exception as f:
            print(str(f))

        return Response(status=status.HTTP_200_OK)

    def getMarketInfo(self, _info):
        try:
            cookieList = self.getCookie()
            
            r = random.randint(1,len(cookieList)-1)
            cookie = cookieList[r]

            headers = {                
                "Referer": "https://www.betfred.com/sports/event/" + _info["event_id"],                
                'Cookie': cookie,                
                'Content-Type': 'application/json'
            }

            url = "https://www.betfred.com/services/SportsBook/event?language=uk&type=event&eventid=" + _info["event_id"] + "&dataflags=14&datasize=8"
            print(url)
            session = requests.Session()
            response = session.get(url, headers=headers)
            #print(response.text)
            result = json.loads(response.text.encode('utf8'))
            
            _result = []
            
            for item in result["Event"]["markets"][0]["selections"]:
                try:
                    horseNo = item["competitornumber"]
                    horseId = item["idfoselection"]
                    horseName = item["name"]
                    odds = 0
                    try:
                        odds = float(item["currentpriceup"]) / float(item["currentpricedown"]) + 1                        
                        odds = "{:.2f}".format(odds)
                    except:
                        pass

                    _result.append({
                        "odds": odds,
                        "horse_no": horseNo,
                        "horse_id": horseId,
                        "horse_name": horseName
                    })
                except:
                    pass
            
            print(len(_result),"save.....","11111111111111")
            #save
            for item in _result:
                try:
                    print(1)
                    count = BetFredMarketInfo.objects.all().filter(horse_id=item["horse_id"]).count()
                    print(2)
                    if count == 0:
                        #insert
                        r = BetFredMarketInfo(name=item["horse_name"],horse_id=item["horse_id"],odds=item["odds"],horse_no=item["horse_no"], updateTime=get_current_time_string())
                        r.save()

                        s = BetFredEvent.objects.get(event_id=_info["event_id"])
                        s.horse.add(r)
                        s.save()
                    else:
                        param = {
                            "odds": item["odds"],                            
                            "updateTime": get_current_time_string()
                        }
                        BetFredMarketInfo.objects.filter(horse_id=item["horse_id"]).update(**param)
                        #update
                except Exception as f:
                    print(str(f),"2")
                    pass

        except Exception as f:
            print(str(f))            
     

    def put(self, reqeust):
        tz = pytz.timezone(settings.TIME_ZONE)
        to_time = (datetime.now(tz) + timedelta(minutes=40)).strftime("%Y-%m-%d %H:%M:%S")
        from_time = (datetime.now(tz) - timedelta(minutes=5)).strftime("%Y-%m-%d %H:%M:%S")
        
        record = BetFredEvent.objects.filter(startTime__gte=from_time).filter(startTime__lte=to_time).order_by('startTime')
        serial = BetFredEventSerializer(record, many=True)

        _result = []
        for item in serial.data:
            _result.append({
                "event_id": item['event_id'],
                "event_title": item['event_title'],
                "startTime": item['startTime'],
                "event_type": item['event_type'],
            })
        #self.getMarketInfo(_result[0])

        for item in _result:
            self.getMarketInfo(item)
        # pool = ThreadPool(3)
        # pool.starmap(self.getMarketInfo, zip(_result))
        # pool.close()
        # pool.join()
        
        return Response(status=status.HTTP_200_OK)

    def get(self, request):
        tz = pytz.timezone(settings.TIME_ZONE)
        to_time = (datetime.now(tz) + timedelta(minutes=40)).strftime("%Y-%m-%d %H:%M:%S")
        from_time = datetime.now(tz).strftime("%Y-%m-%d %H:%M:%S")
        
        record = BetFredEvent.objects.filter(startTime__gte=from_time).filter(startTime__lte=to_time).order_by('startTime')        
        serial = BetFredEventSerializer(record, many=True)
            
        return Response(serial.data, status=status.HTTP_200_OK)