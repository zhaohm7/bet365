from django.urls import path, re_path
from rest_framework.urlpatterns import format_suffix_patterns
from rest_framework.authtoken.views import obtain_auth_token
from backend import views
from django.conf.urls import include
from django.conf.urls.static import static
from django.conf import settings

urlpatterns = static(settings.CSS_URL, document_root=settings.CSS_ROOT) + [
    path('api/auth', views.CustomObtainAuthToken.as_view()),    
    path('api/test/bet365', views.Bet365View.as_view()),
    path('api/tom/bet365', views.Bet365ToView.as_view()),

    path('api/sportsinfo', views.SportsInfoView.as_view()),
    path('api/sportsinfo/<int:pk>', views.SportsInfoView.as_view()),

    path('api/bet365/token', views.Bet365TokenView.as_view()),
    #path('api/bet365/cookie', views.Bet365CookieView.as_view()),
    #path('api/bet365/token/<int:pk>', views.Bet365CookieView.as_view()),
    path('api/bet365/cookie/<int:pk>', views.Bet365CookieView.as_view()),

    path('api/betfred/cookie/<int:pk>', views.BetFredCookieView.as_view()),    
    path('api/test/betfred', views.BetFredView.as_view()),
    path('api/tom/betfred', views.BetFredTomView.as_view()),
    re_path(r'^.*$', views.index),    
] 

urlpatterns = format_suffix_patterns(urlpatterns)

