'use strict';
const puppeteer = require("puppeteer-extra");
const path = require("path");
const RecaptchaPlugin = require('puppeteer-extra-plugin-recaptcha')

const StealthPlugin = require("puppeteer-extra-plugin-stealth")();
StealthPlugin.enabledEvasions.delete("chrome.runtime");
StealthPlugin.enabledEvasions.delete("iframe.contentWindow");

const request = require('request');
puppeteer.use(StealthPlugin);

const id = 3;
puppeteer.use(
  RecaptchaPlugin({
    provider: { id: '2captcha', token: '70ae0bc08d29396a72eb755fbabea507' },
    visualFeedback: true // colorize reCAPTCHAs (violet = detected, green = solved)
  })
)
const reset = () => {
  request.post('http://localhost:8000/api/betfred/cookie/' + id , {form:{cookie: null}}, function(err, response, body) {
    if (err)
        console.log("error", err)
});
}



(async () => {


const puppeteerBrowser = await puppeteer.launch({
  headless: false,
  userDataDir: path.resolve(__dirname, "./perfil"),
  args: [
    "--disable-infobars",
    "--no-sandbox",
    "--disable-blink-features=AutomationControlled",
  ],
  ignoreDefaultArgs: ["--enable-automation"],
});

const puppeteerPage = await puppeteerBrowser.newPage();

await puppeteerPage.evaluateOnNewDocument(() => {
  window.qs = document.querySelector;
  window.qsAll = document.querySelectorAll;
  
  let n = 1;

  Object.defineProperty(navigator, "maxTouchPoints", {
    get() {
      setTimeout(() => (n = 0), 0);
      return n;
    },
  });

  navigator.permissions.query = i => ({then: f => f({state: "prompt", onchange: null})});
});

await puppeteerPage.goto("https://www.betfred.com/sports/horses/today", { waitUntil: "networkidle0" });
let flag = false;

const detectCaptcha = async() => {
  while (true)
  {
      console.log("Waiting.....")
      let xpath = null;
          
      try {
          const ele = await puppeteerPage.$('iframe#main-iframe');        
          const _frame = await ele.contentFrame();        
          const frame = await _frame.$("div.g-recaptcha iframe[title='reCAPTCHA']");
          
          await _frame.waitForSelector('iframe[src*="recaptcha/"]')
          console.log("detect the captcha")
          reset();
          flag = true
          await _frame.solveRecaptchas()
          console.log("solved the captcha")
          await puppeteerPage.waitForTimeout(3000);          
      } catch(err) {
          try {            
              xpath = "//div[@id='MainHeader']"
              await puppeteerPage.waitForXPath(xpath, { visible: true, timeout: 10000})            
              flag = false;
              break;
          } catch(err) {
              console.log(err)
              await puppeteerPage.waitForTimeout(3000);
          }
      }    
  }
}

await detectCaptcha();


await puppeteerPage.evaluate(() => {
  document.querySelector = window.qs;
  document.querySelectorAll = window.qsAll;
});

await puppeteerPage.waitForTimeout(3000);

var cookie = "";

setInterval(async() => {
  try {
    flag = true;
    console.log("refresh")
    await puppeteerPage.reload()

    await detectCaptcha();
  } catch(err) {
    
  }
}, 3 * 60 * 1000)

console.log("Starting...........................")

puppeteerPage.on('request', async (requests) => {
    let t = await requests.headers();
 
    try {
        const current_url_cookies = await puppeteerPage.cookies();
        let cookie_string = ""
        current_url_cookies.forEach(item => {
            cookie_string += item['name'] + "=" + item["value"] + "; "
        })
    
        cookie_string = cookie_string.substr(0, cookie_string.length-2)

        if (cookie != cookie_string)
        {                   
          if (!flag) {            
            request.post('http://localhost:8000/api/betfred/cookie/' + id, {form:{cookie: cookie_string}}, function(err, response, body) {
              if (err)
                  console.log("error", err)
            })
          }
        }
    } catch(err) {}
});

})();
